// Fast sanity check: every JS file parses, index.html references files that exist,
// and the service-worker shell list matches reality. Run with: npm run check
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const www = fileURLToPath(new URL('../www/', import.meta.url));
let errors = 0;
const fail = (m) => { errors++; console.error('✗ ' + m); };

for (const f of fs.readdirSync(path.join(www, 'js'))) {
  try { new vm.Script(fs.readFileSync(path.join(www, 'js', f), 'utf8'), { filename: f }); }
  catch (e) { fail(`${f}: ${e.message}`); }
}
try { new vm.Script(fs.readFileSync(path.join(www, 'sw.js'), 'utf8')); } catch (e) { fail('sw.js: ' + e.message); }

const html = fs.readFileSync(path.join(www, 'index.html'), 'utf8');
const refs = [...html.matchAll(/(?:src|href)="([^"#?]+)"/g)].map(m => m[1]).filter(r => !/^https?:/.test(r));
for (const r of refs) if (!fs.existsSync(path.join(www, r))) fail(`index.html references missing file: ${r}`);

const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
const used = new Set();
for (const f of fs.readdirSync(path.join(www, 'js'))) {
  const src = fs.readFileSync(path.join(www, 'js', f), 'utf8');
  for (const m of src.matchAll(/\$\('([^']+)'\)|getElementById\('([^']+)'\)/g)) used.add(m[1] || m[2]);
}
for (const id of used) if (!ids.has(id)) fail(`JS looks up #${id} but index.html has no such id`);

const sw = fs.readFileSync(path.join(www, 'sw.js'), 'utf8');
for (const m of sw.matchAll(/'([\w./-]+\.(?:js|css|html|png|svg|webmanifest))'/g)) {
  if (!fs.existsSync(path.join(www, m[1]))) fail(`sw.js caches missing file: ${m[1]}`);
}
const man = JSON.parse(fs.readFileSync(path.join(www, 'manifest.webmanifest'), 'utf8'));
for (const i of man.icons) if (!fs.existsSync(path.join(www, i.src))) fail(`manifest icon missing: ${i.src}`);

if (errors) { console.error(`\n${errors} problem(s)`); process.exit(1); }
console.log('✓ all checks passed');
