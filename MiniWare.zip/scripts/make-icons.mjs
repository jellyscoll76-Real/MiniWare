// Regenerates PNG icons from www/icons/icon.svg. Needs Playwright (not a project dependency):
//   npx playwright install chromium && node scripts/make-icons.mjs
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const dir = fileURLToPath(new URL('../www/icons/', import.meta.url));
const svg = await readFile(dir + 'icon.svg', 'utf8');
const browser = await chromium.launch();

async function png(size, name, { maskable = false } = {}) {
  const page = await browser.newPage({ viewport: { width: size, height: size } });
  const inner = maskable
    ? `<div style="width:${size}px;height:${size}px;background:#6c4ee6;display:grid;place-items:center"><div style="width:${size * 0.7}px;height:${size * 0.7}px">${svg}</div></div>`
    : `<div style="width:${size}px;height:${size}px">${svg}</div>`;
  await page.setContent(`<style>*{margin:0}svg{width:100%;height:100%;display:block}</style>${inner}`);
  await writeFile(dir + name, await page.screenshot({ omitBackground: true }));
  await page.close();
}

await png(192, 'icon-192.png');
await png(512, 'icon-512.png');
await png(512, 'icon-maskable-512.png', { maskable: true });
await browser.close();
console.log('icons written');
