/* MiniWare — timeline.js
 * Multi-track timeline UI: ruler, tracks, clips, draggable playhead, move / trim / drop from bin.
 * The DOM is rebuilt on every state change; drags use window listeners and only commit on release.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var U = MW.util, h = U.h, S = MW.store, OPS = MW.clipops, SP = MW.speed, E = MW.engine, bus = MW.bus;

  var HEAD_W = 132, ROW_H = 54;
  var MIN_PPS = 12, MAX_PPS = 300;
  var pps = 60;
  var scroll = null, inner = null, playheadEl = null;
  var snapOn = true;

  var ICONS = {
    eye: '<svg viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    eyeOff: '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 5.1A10 10 0 0112 5c6.4 0 10 7 10 7a17 17 0 01-3.2 4M6.5 6.5A17 17 0 002 12s3.6 7 10 7a10 10 0 004.2-.9"/></svg>',
    vol: '<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16.5 8.5a5 5 0 010 7"/></svg>',
    volOff: '<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M17 9l5 6M22 9l-5 6"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>'
  };

  function iconBtn(name, title, onclick) {
    var b = h('button', { class: 'mini', title: title, type: 'button', onclick: onclick });
    b.innerHTML = ICONS[name];
    return b;
  }

  /* ---------- public setters ---------- */
  function setPps(v) {
    var old = pps;
    pps = U.clamp(v, MIN_PPS, MAX_PPS);
    if (pps === old || !scroll) return;
    var viewW = Math.max(0, scroll.clientWidth - HEAD_W);
    var center = (scroll.scrollLeft + viewW / 2) / old;
    render();
    scroll.scrollLeft = Math.max(0, center * pps - viewW / 2);
    bus.emit('zoom', pps);
  }
  function ppsToSlider(p) { return 100 * Math.log(p / MIN_PPS) / Math.log(MAX_PPS / MIN_PPS); }
  function sliderToPps(v) { return MIN_PPS * Math.pow(MAX_PPS / MIN_PPS, v / 100); }

  /* ---------- rendering ---------- */
  function render() {
    if (!scroll || !S.project) return;
    var dur = Math.max(S.duration(), 10);
    var viewSec = scroll.clientWidth ? (scroll.clientWidth - HEAD_W) / pps : 10;
    var totalSec = Math.max(dur + Math.max(5, dur * 0.25), viewSec);
    var laneW = Math.ceil(totalSec * pps);

    var sl = scroll.scrollLeft, st = scroll.scrollTop;
    inner = h('div', { class: 'tl-inner', style: { width: (HEAD_W + laneW) + 'px' } });
    inner.appendChild(buildRuler(totalSec, laneW));
    S.project.tracks.forEach(function (tr) { inner.appendChild(buildRow(tr, laneW)); });
    playheadEl = h('div', { class: 'tl-playhead' }, h('div', { class: 'tl-playhead-cap' }));
    inner.appendChild(playheadEl);

    scroll.innerHTML = '';
    scroll.appendChild(inner);
    scroll.scrollLeft = sl;
    scroll.scrollTop = st;
    positionPlayhead(E.getTime());
  }

  function buildRuler(totalSec, laneW) {
    var steps = [0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 1800];
    var step = steps[steps.length - 1];
    for (var i = 0; i < steps.length; i++) if (steps[i] * pps >= 84) { step = steps[i]; break; }
    var minor = Math.max(4, step * pps / 5);
    var track = h('div', {
      class: 'tl-ruler-track',
      style: {
        width: laneW + 'px',
        backgroundImage: 'repeating-linear-gradient(90deg, rgba(255,255,255,.14) 0, rgba(255,255,255,.14) 1px, transparent 1px, transparent ' + minor + 'px)'
      }
    });
    var n = Math.floor(totalSec / step);
    for (var k = 0; k <= n; k++) {
      var t = k * step;
      track.appendChild(h('div', { class: 'tl-tick', style: { left: (t * pps) + 'px' } }, h('span', null, U.fmtShort(t))));
    }
    return h('div', { class: 'tl-ruler' }, h('div', { class: 'tl-corner' }), track);
  }

  function buildRow(tr, laneW) {
    var isAudio = tr.type === 'audio';
    var off = isAudio ? tr.muted : tr.hidden;
    var toggle = iconBtn(isAudio ? (off ? 'volOff' : 'vol') : (off ? 'eyeOff' : 'eye'),
      isAudio ? 'Mute / unmute track' : 'Show / hide track',
      function () {
        S.mutate(function () {
          var t = S.track(tr.id);
          if (!t) return;
          if (isAudio) t.muted = !t.muted; else t.hidden = !t.hidden;
        });
      });
    var del = iconBtn('close', 'Delete track', function () {
      S.mutate(function () { S.removeTrack(tr.id); });
    });
    var head = h('div', { class: 'tl-head t-' + tr.type + (off ? ' off' : '') },
      h('span', { class: 'tl-name', title: tr.name }, tr.name),
      h('div', { class: 'tl-head-btns' }, toggle, del));

    var lane = h('div', { class: 'tl-lane t-' + tr.type + (off ? ' off' : ''), dataset: { track: tr.id }, style: { width: laneW + 'px' } });
    var selId = S.selectedId();
    tr.clips.forEach(function (c) { lane.appendChild(buildClip(c, c.id === selId)); });
    return h('div', { class: 'tl-row', style: { height: ROW_H + 'px' } }, head, lane);
  }

  function clipLabel(c) {
    var s = c.type === 'text' ? (c.text.content || 'Text').split('\n')[0] : c.name;
    if (c.type === 'video' || c.type === 'audio') {
      if (c.curve !== 'none') s += '  ⟿';
      else if (Math.abs(c.speed - 1) > 0.005) s += '  ' + (Math.round(c.speed * 100) / 100) + '×';
    }
    return s;
  }

  function buildClip(c, selected) {
    var asset = c.assetId ? S.assets.get(c.assetId) : null;
    var el = h('div', {
      class: 'clip t-' + c.type + (selected ? ' sel' : ''),
      dataset: { id: c.id },
      style: { left: (c.start * pps) + 'px', width: Math.max(4, c.dur * pps) + 'px' }
    });
    if (asset && asset.thumb && c.type !== 'audio') el.style.backgroundImage = 'url("' + asset.thumb + '")';
    if (c.type === 'audio' && asset && asset.peaks) el.appendChild(waveCanvas(c, asset));
    el.appendChild(h('div', { class: 'clip-label' }, clipLabel(c)));
    el.appendChild(h('div', { class: 'h h-l' }));
    el.appendChild(h('div', { class: 'h h-r' }));
    if (selected) {
      OPS.allKfTimes(c).forEach(function (t) {
        el.appendChild(h('div', {
          class: 'kfm', title: 'Keyframe',
          style: { left: (t * pps - 5) + 'px' },
          onpointerdown: function (ev) { ev.stopPropagation(); ev.preventDefault(); E.seek(c.start + t); }
        }));
      });
    }
    return el;
  }

  function waveCanvas(c, asset) {
    var wpx = Math.max(2, Math.min(Math.floor(c.dur * pps), 4096)), hpx = ROW_H - 8 - 16;
    var cv = h('canvas', { class: 'wave', width: wpx, height: hpx });
    var g = cv.getContext('2d'), peaks = asset.peaks, n = peaks.length;
    g.fillStyle = 'rgba(190,255,215,0.85)';
    for (var x = 0; x < wpx; x++) {
      var tau = c.dur * x / wpx;
      var src = c.srcIn + SP.srcOffset(c, tau);
      var idx = U.clamp(Math.floor(src / asset.duration * n), 0, n - 1);
      var a = Math.max(0.5, peaks[idx] * (hpx / 2 - 1));
      g.fillRect(x, hpx / 2 - a, 1, a * 2);
    }
    return cv;
  }

  function positionPlayhead(t) {
    if (playheadEl) playheadEl.style.transform = 'translateX(' + (HEAD_W + t * pps) + 'px)';
  }

  function onTime(t) {
    positionPlayhead(t);
    if (!scroll || !E.isPlaying()) return;
    var x = HEAD_W + t * pps;
    if (x > scroll.scrollLeft + scroll.clientWidth - 30 || x < scroll.scrollLeft + HEAD_W) {
      scroll.scrollLeft = Math.max(0, t * pps - 30);
    }
  }

  /* ---------- interaction ---------- */
  function laneEl(trackId) { return inner.querySelector('.tl-lane[data-track="' + trackId + '"]'); }

  function trackAt(x, y) {
    var n = document.elementFromPoint(x, y);
    var lane = n && n.closest ? n.closest('.tl-lane') : null;
    return lane ? S.track(lane.dataset.track) : null;
  }

  function snapPoints(excludeId) {
    var pts = [0, E.getTime()];
    S.project.tracks.forEach(function (tr) {
      tr.clips.forEach(function (c) {
        if (c.id === excludeId) return;
        pts.push(c.start, c.start + c.dur);
      });
    });
    return pts;
  }
  function snapTo(v, pts) {
    var thr = 8 / pps, best = null, bd = thr;
    pts.forEach(function (p) { var d = Math.abs(v - p); if (d < bd) { bd = d; best = p; } });
    return best;
  }
  function snapMove(start, dur, id) {
    if (!snapOn) return start;
    var pts = snapPoints(id);
    var a = snapTo(start, pts), b = snapTo(start + dur, pts);
    var da = a == null ? Infinity : Math.abs(a - start), db = b == null ? Infinity : Math.abs(b - (start + dur));
    if (da === Infinity && db === Infinity) return start;
    return da <= db ? a : b - dur;
  }
  function snapEdge(v, id) {
    if (!snapOn) return v;
    var p = snapTo(v, snapPoints(id));
    return p == null ? v : p;
  }

  function trackEvents(move, up) {
    function end(ev) {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', end);
      window.removeEventListener('pointercancel', end);
      up(ev);
    }
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
  }

  function startScrub(e) {
    e.preventDefault();
    function seekTo(ev) {
      var r = inner.getBoundingClientRect();
      E.seek(Math.max(0, (ev.clientX - r.left - HEAD_W) / pps));
    }
    seekTo(e);
    trackEvents(seekTo, function () {});
  }

  function startClipDrag(e, mode, id) {
    var f = S.find(id);
    if (!f) return;
    e.preventDefault();
    S.select(id);
    f = S.find(id);
    var orig = U.clone(f.clip), origTrackId = f.track.id;
    var bounds = S.boundsFor(f.clip);
    var startX = e.clientX, startY = e.clientY, moved = false, result = null;

    function node() { return inner.querySelector('.clip[data-id="' + id + '"]'); }

    function move(ev) {
      var dx = ev.clientX - startX, dy = ev.clientY - startY;
      if (!moved) {
        if (Math.abs(dx) < 3 && Math.abs(dy) < 3) return;
        moved = true;
        var n0 = node();
        if (n0) n0.classList.add('dragging');
      }
      var n = node();
      if (!n) return;
      var dSec = dx / pps;
      if (mode === 'move') {
        var target = trackAt(ev.clientX, ev.clientY);
        var tr = target && S.accepts(target, orig.type) ? target : S.track(origTrackId);
        var desired = snapMove(orig.start + dSec, orig.dur, id);
        var s = S.resolveStart(tr, id, desired, orig.dur);
        if (s == null) { tr = S.track(origTrackId); s = orig.start; }
        result = { trackId: tr.id, start: s };
        n.style.left = (s * pps) + 'px';
        var dyPx = laneEl(tr.id).getBoundingClientRect().top - laneEl(origTrackId).getBoundingClientRect().top;
        n.style.transform = 'translateY(' + dyPx + 'px)';
      } else if (mode === 'trimL') {
        var dL = snapEdge(orig.start + dSec, id) - orig.start;
        var nl = OPS.trimLeft(orig, dL, bounds) || orig;
        result = { clip: nl };
        n.style.left = (nl.start * pps) + 'px';
        n.style.width = Math.max(4, nl.dur * pps) + 'px';
      } else {
        var dR = snapEdge(orig.start + orig.dur + dSec, id) - (orig.start + orig.dur);
        var nr = OPS.trimRight(orig, dR, bounds) || orig;
        result = { clip: nr };
        n.style.width = Math.max(4, nr.dur * pps) + 'px';
      }
    }

    function up(ev) {
      if (!moved || !result || (ev && ev.type === 'pointercancel')) { if (moved) render(); return; }
      if (mode === 'move') {
        if (result.trackId !== origTrackId || Math.abs(result.start - orig.start) > 1e-4) {
          S.mutate(function () { S.moveClip(id, result.trackId, result.start); });
        } else render();
      } else if (result.clip !== orig) {
        S.mutate(function () { S.replaceClip(result.clip); });
      } else render();
    }

    trackEvents(move, up);
  }

  function onPointerDown(e) {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    var t = e.target;
    var clipEl = t.closest('.clip');
    if (clipEl) {
      var handle = t.closest('.h');
      var mode = handle ? (handle.classList.contains('h-l') ? 'trimL' : 'trimR') : 'move';
      startClipDrag(e, mode, clipEl.dataset.id);
      return;
    }
    if (t.closest('.tl-ruler-track')) { startScrub(e); return; }
    if (t.closest('.tl-lane')) { S.select(null); startScrub(e); }
  }

  /* ---------- drag & drop from the media bin ---------- */
  function hasAsset(e) {
    return e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'text/miniware-asset') >= 0;
  }
  function clearDrop() {
    var l = scroll.querySelectorAll('.tl-lane.drop');
    for (var i = 0; i < l.length; i++) l[i].classList.remove('drop');
  }
  function onDragOver(e) {
    if (!hasAsset(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    clearDrop();
    var lane = e.target.closest('.tl-lane');
    if (lane) lane.classList.add('drop');
  }
  function onDrop(e) {
    if (!hasAsset(e)) return;
    e.preventDefault();
    var id = e.dataTransfer.getData('text/miniware-asset');
    var lane = e.target.closest('.tl-lane');
    clearDrop();
    var r = inner.getBoundingClientRect();
    var start = Math.max(0, (e.clientX - r.left - HEAD_W) / pps);
    S.mutate(function () { S.addAssetClip(id, { trackId: lane ? lane.dataset.track : null, start: start }); });
  }

  function onWheel(e) {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    setPps(pps * (e.deltaY < 0 ? 1.15 : 1 / 1.15));
  }

  function init(scrollEl) {
    scroll = scrollEl;
    bus.on('change', render);
    bus.on('selection', render);
    bus.on('assetupdate', render);
    bus.on('time', onTime);
    scroll.addEventListener('pointerdown', onPointerDown);
    scroll.addEventListener('dragover', onDragOver);
    scroll.addEventListener('dragleave', function (e) { if (e.target === scroll) clearDrop(); });
    scroll.addEventListener('drop', onDrop);
    scroll.addEventListener('wheel', onWheel, { passive: false });
    if (global.ResizeObserver) new ResizeObserver(function () { render(); }).observe(scroll);
    render();
  }

  MW.timeline = {
    init: init, render: render,
    setPps: setPps, getPps: function () { return pps; },
    setSliderValue: function (v) { setPps(sliderToPps(v)); },
    sliderValue: function () { return ppsToSlider(pps); },
    setSnap: function (v) { snapOn = !!v; },
    HEAD_W: HEAD_W
  };
})(typeof window !== 'undefined' ? window : globalThis);
