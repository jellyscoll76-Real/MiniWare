/* MiniWare — store.js
 * Project state, selection, undo/redo (JSON snapshots) and all edit actions.
 * Assets (File blobs / media elements) live outside the history in `assets`.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var U = MW.util, OPS = MW.clipops, A = MW.anim, bus = MW.bus;

  var MAX_HISTORY = 100;
  var COALESCE_MS = 800;

  var RANK = { text: 0, overlay: 1, video: 2, audio: 3 };
  var LABEL = { text: 'Text', overlay: 'Overlay', video: 'Video', audio: 'Audio' };

  var st = {
    project: null,
    assets: new Map(),
    selectedId: null,
    undo: [],
    redo: [],
    lastKey: null,
    lastTime: 0
  };

  function newTrack(type, n) {
    return { id: U.uid('trk'), type: type, name: LABEL[type] + ' ' + n, hidden: false, muted: false, clips: [] };
  }

  function newProject() {
    return {
      aspect: '16:9',
      tracks: [newTrack('text', 1), newTrack('overlay', 1), newTrack('video', 1), newTrack('audio', 1)]
    };
  }

  var S = (MW.store = {
    assets: st.assets,
    get project() { return st.project; },

    init: function () {
      st.project = newProject();
      st.undo = []; st.redo = [];
      st.selectedId = null;
      bus.emit('change');
    },

    /* ---------- history ---------- */
    checkpoint: function (key) {
      var now = Date.now();
      if (key && key === st.lastKey && now - st.lastTime < COALESCE_MS) {
        st.lastTime = now;
        return;
      }
      st.undo.push(JSON.stringify(st.project));
      if (st.undo.length > MAX_HISTORY) st.undo.shift();
      st.redo = [];
      st.lastKey = key || null;
      st.lastTime = now;
    },
    update: function (fn) { fn(st.project); bus.emit('change'); },
    mutate: function (fn, key) { S.checkpoint(key); fn(st.project); bus.emit('change'); },

    canUndo: function () { return st.undo.length > 0; },
    canRedo: function () { return st.redo.length > 0; },
    undo: function () {
      if (!st.undo.length) return;
      st.redo.push(JSON.stringify(st.project));
      st.project = JSON.parse(st.undo.pop());
      st.lastKey = null;
      afterRestore();
    },
    redo: function () {
      if (!st.redo.length) return;
      st.undo.push(JSON.stringify(st.project));
      st.project = JSON.parse(st.redo.pop());
      st.lastKey = null;
      afterRestore();
    },

    /* ---------- lookups ---------- */
    find: function (id) {
      var tracks = st.project.tracks;
      for (var i = 0; i < tracks.length; i++) {
        var cl = tracks[i].clips;
        for (var j = 0; j < cl.length; j++) if (cl[j].id === id) return { clip: cl[j], track: tracks[i], ti: i, ci: j };
      }
      return null;
    },
    track: function (id) {
      return st.project.tracks.filter(function (t) { return t.id === id; })[0] || null;
    },
    selected: function () {
      var f = st.selectedId && S.find(st.selectedId);
      return f ? f.clip : null;
    },
    selectedId: function () { return st.selectedId; },
    select: function (id) {
      if (st.selectedId === id) return;
      st.selectedId = id || null;
      bus.emit('selection', st.selectedId);
    },
    duration: function () {
      var d = 0;
      st.project.tracks.forEach(function (t) { t.clips.forEach(function (c) { d = Math.max(d, c.start + c.dur); }); });
      return d;
    },
    hasClips: function () {
      return st.project.tracks.some(function (t) { return t.clips.length > 0; });
    },
    accepts: function (track, clipType) {
      if (track.type === 'audio') return clipType === 'audio';
      if (track.type === 'text') return clipType === 'text';
      return clipType === 'video' || clipType === 'image';
    },
    /** neighbours of a clip on its track: free space before/after */
    boundsFor: function (clip) {
      var f = S.find(clip.id);
      var prevEnd = 0, nextStart = Infinity;
      if (f) {
        f.track.clips.forEach(function (o) {
          if (o.id === clip.id) return;
          if (o.start + o.dur <= clip.start + 1e-6) prevEnd = Math.max(prevEnd, o.start + o.dur);
          else if (o.start >= clip.start + clip.dur - 1e-6) nextStart = Math.min(nextStart, o.start);
        });
      }
      var asset = clip.assetId ? st.assets.get(clip.assetId) : null;
      var assetDur = OPS.isMedia(clip) && asset && asset.duration > 0 ? asset.duration - 0.02 : Infinity;
      return { minStart: prevEnd, maxEnd: nextStart, assetDur: assetDur };
    },

    /** Closest free start for a clip of length `dur` on `track` (ignores clip `excludeId`). */
    resolveStart: function (track, excludeId, desired, dur) {
      desired = Math.max(0, desired);
      var others = track.clips
        .filter(function (c) { return c.id !== excludeId; })
        .sort(function (a, b) { return a.start - b.start; });
      var gaps = [], cursor = 0;
      others.forEach(function (c) {
        if (c.start - cursor >= dur - 1e-6) gaps.push([cursor, c.start]);
        cursor = Math.max(cursor, c.start + c.dur);
      });
      gaps.push([cursor, Infinity]);
      var best = null, bestDist = Infinity;
      gaps.forEach(function (g) {
        var hi = g[1] - dur;
        if (hi < g[0] - 1e-6) return;
        var s = U.clamp(desired, g[0], Math.max(g[0], hi));
        var dist = Math.abs(s - desired);
        if (dist < bestDist) { bestDist = dist; best = s; }
      });
      return best;
    },

    /* ---------- assets ---------- */
    addAsset: function (asset) {
      st.assets.set(asset.id, asset);
      bus.emit('assets', asset);
    },

    /* ---------- tracks ---------- */
    addTrack: function (type) {
      var n = st.project.tracks.filter(function (t) { return t.type === type; }).length + 1;
      var t = newTrack(type, n);
      var tracks = st.project.tracks, idx = tracks.length;
      for (var i = 0; i < tracks.length; i++) {
        if (RANK[tracks[i].type] >= RANK[type]) { idx = i; break; }
      }
      tracks.splice(idx, 0, t);
      return t;
    },
    removeTrack: function (id) {
      var tracks = st.project.tracks;
      var i = tracks.findIndex(function (t) { return t.id === id; });
      if (i < 0) return;
      var selected = st.selectedId;
      tracks[i].clips.forEach(function (c) { if (c.id === selected) st.selectedId = null; });
      tracks.splice(i, 1);
    },

    /* ---------- adding clips ---------- */
    pickTrack: function (clipType, preferredId) {
      var p = preferredId && S.track(preferredId);
      if (p && S.accepts(p, clipType)) return p;
      var tracks = st.project.tracks;
      var want = clipType === 'audio' ? ['audio'] : clipType === 'text' ? ['text'] : ['video', 'overlay'];
      for (var w = 0; w < want.length; w++) {
        for (var i = tracks.length - 1; i >= 0; i--) if (tracks[i].type === want[w]) return tracks[i];
      }
      return S.addTrack(want[0]);
    },

    /** Add a media clip. Call inside S.mutate. Returns the clip. */
    addAssetClip: function (assetId, opts) {
      opts = opts || {};
      var asset = st.assets.get(assetId);
      if (!asset) return null;
      var pref = opts.trackId && S.track(opts.trackId);
      var type = asset.kind;
      if (asset.kind === 'video' && pref && pref.type === 'audio') type = 'audio';
      if (asset.kind === 'audio') type = 'audio';
      var track = S.pickTrack(type, opts.trackId);
      var dur = type === 'image' ? 5 : (asset.duration > 0 && isFinite(asset.duration) ? asset.duration : 5);
      var start = S.resolveStart(track, null, opts.start == null ? 0 : opts.start, dur);
      if (start == null) start = 0;
      var clip = OPS.makeClip(type, { assetId: assetId, name: asset.name, start: start, dur: dur });
      track.clips.push(clip);
      st.selectedId = clip.id;
      return clip;
    },
    addTextClip: function (start) {
      var track = S.pickTrack('text');
      var s = S.resolveStart(track, null, start || 0, 3);
      var clip = OPS.makeClip('text', { name: 'Text', start: s == null ? 0 : s, dur: 3 });
      track.clips.push(clip);
      st.selectedId = clip.id;
      return clip;
    },

    /* ---------- edit actions (call inside S.mutate unless noted) ---------- */
    deleteSelected: function () {
      var f = st.selectedId && S.find(st.selectedId);
      if (!f) return false;
      f.track.clips.splice(f.ci, 1);
      st.selectedId = null;
      return true;
    },
    /** Clips a split at time t would cut: the selected clip, or every clip crossing t. */
    splitTargets: function (t) {
      var list = [];
      var sel = S.selected();
      if (sel) list = [sel];
      else st.project.tracks.forEach(function (tr) {
        tr.clips.forEach(function (c) { if (t > c.start && t < c.start + c.dur) list.push(c); });
      });
      return list.filter(function (c) {
        return t - c.start >= OPS.MIN_DUR && c.start + c.dur - t >= OPS.MIN_DUR;
      });
    },
    canSplit: function (t) { return S.splitTargets(t).length > 0; },
    /** Split selected clip at time t (or every clip crossing t when nothing is selected). */
    splitAt: function (t) {
      var n = 0;
      S.splitTargets(t).forEach(function (c) {
        var parts = OPS.split(c, t - c.start, U.uid('clip'));
        if (!parts) return;
        var f = S.find(c.id);
        f.track.clips.splice(f.ci, 1, parts[0], parts[1]);
        if (st.selectedId === c.id) st.selectedId = parts[1].id;
        n++;
      });
      return n;
    },
    replaceClip: function (newClip) {
      var f = S.find(newClip.id);
      if (f) f.track.clips[f.ci] = newClip;
    },
    moveClip: function (id, trackId, start) {
      var f = S.find(id), tr = S.track(trackId);
      if (!f || !tr) return;
      f.clip.start = Math.max(0, start);
      if (f.track.id !== tr.id) {
        f.track.clips.splice(f.ci, 1);
        tr.clips.push(f.clip);
      }
      tr.clips.sort(function (a, b) { return a.start - b.start; });
    },
    mutateClip: function (id, fn, key) {
      S.mutate(function () { var f = S.find(id); if (f) fn(f.clip, f.track); }, key);
    },
    retime: function (id, patch, key) {
      S.mutate(function () {
        var f = S.find(id);
        if (!f) return;
        var b = S.boundsFor(f.clip);
        f.track.clips[f.ci] = OPS.retime(f.clip, patch, b.maxEnd);
      }, key);
    },

    /* ---------- keyframes / properties ---------- */
    setProps: function (id, values, tau, key) {
      S.mutate(function () {
        var f = S.find(id);
        if (!f) return;
        var c = f.clip;
        Object.keys(values).forEach(function (p) {
          if (c.kf[p].length) A.upsert(c.kf[p], tau, values[p]);
          else c.base[p] = values[p];
        });
      }, key);
    },
    toggleKeyframe: function (id, prop, tau) {
      S.mutate(function () {
        var f = S.find(id);
        if (!f) return;
        var c = f.clip, kfs = c.kf[prop];
        var cur = OPS.evalProp(c, prop, tau);
        if (A.indexNear(kfs, tau) >= 0) {
          A.removeNear(kfs, tau);
          if (!kfs.length) c.base[prop] = cur;
        } else {
          A.upsert(kfs, tau, cur);
        }
      });
    },
    addKeyframesAll: function (id, tau, ease) {
      S.mutate(function () {
        var f = S.find(id);
        if (!f) return;
        OPS.PROPS.forEach(function (p) {
          A.upsert(f.clip.kf[p], tau, OPS.evalProp(f.clip, p, tau), ease);
        });
      });
    },
    setKeyEase: function (id, tau, ease) {
      S.mutate(function () {
        var f = S.find(id);
        if (!f) return;
        OPS.PROPS.forEach(function (p) {
          var i = A.indexNear(f.clip.kf[p], tau);
          if (i >= 0) f.clip.kf[p][i].ease = ease;
        });
      }, 'ease:' + id);
    },
    clearKeyframes: function (id, tau) {
      S.mutate(function () {
        var f = S.find(id);
        if (!f) return;
        OPS.PROPS.forEach(function (p) {
          if (f.clip.kf[p].length) {
            f.clip.base[p] = OPS.evalProp(f.clip, p, tau);
            f.clip.kf[p] = [];
          }
        });
      });
    },
    /** Decaying camera-shake burst on X / Y / rotation starting at tau. */
    addShake: function (id, tau, length, intensity) {
      length = length || 0.6;
      intensity = intensity || 1;
      S.mutate(function () {
        var f = S.find(id);
        if (!f) return;
        var c = f.clip, steps = 10;
        var t1 = Math.min(c.dur, tau + length);
        var span = t1 - tau;
        if (span < 0.05) return;
        var amps = { x: 2.2, y: 2.2, rotation: 2.5 };
        Object.keys(amps).forEach(function (p) {
          var kfs = c.kf[p];
          var baseV = OPS.evalProp(c, p, tau);
          var endV = OPS.evalProp(c, p, t1);
          c.kf[p] = kfs.filter(function (k) { return k.t < tau - 0.01 || k.t > t1 + 0.01; });
          if (!c.kf[p].length && !kfs.length) endV = baseV;
          for (var i = 0; i <= steps; i++) {
            var t = tau + span * i / steps;
            var decay = 1 - i / steps;
            var off = i === 0 ? 0 : (Math.random() * 2 - 1) * amps[p] * intensity * decay;
            var v = i === steps ? endV : baseV + off;
            A.upsert(c.kf[p], t, U.round(v, 2), 'linear');
          }
        });
      });
    }
  });

  function afterRestore() {
    if (st.selectedId && !S.find(st.selectedId)) {
      st.selectedId = null;
      bus.emit('selection', null);
    }
    bus.emit('change');
  }
})(typeof window !== 'undefined' ? window : globalThis);
