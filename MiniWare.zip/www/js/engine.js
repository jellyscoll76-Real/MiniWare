/* MiniWare — engine.js
 * Canvas compositor + playback clock + media element sync.
 * Per clip: keyframed transform → (chroma key → RGB split → vignette) → filters → blend → canvas.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var U = MW.util, S = MW.store, OPS = MW.clipops, SP = MW.speed, bus = MW.bus, EASE = MW.easing.fns;

  var RES = { '16:9': [1280, 720], '9:16': [720, 1280], '1:1': [900, 900] };
  var BLEND = { normal: 'source-over', screen: 'screen', multiply: 'multiply', overlay: 'overlay' };
  var SCRATCH_MAX = 960;

  var canvas, ctx, ov, ovx;
  var time = 0, playing = false, raf = 0, lastNow = 0, pending = false, exporting = false;
  var supportsFilter = false;
  var els = new Map();       // "trackId|assetId" -> HTMLMediaElement
  var boxes = new Map();     // clipId -> {cx, cy, w, h, rot} for the frame just drawn
  var boxOrder = [];         // clip ids, top-most first
  var sa, sb, sc;            // scratch canvases

  function mk(willRead) {
    var c = document.createElement('canvas');
    c.width = 2; c.height = 2;
    return { c: c, x: c.getContext('2d', willRead ? { willReadFrequently: true } : undefined) };
  }
  function sizeCanvas(o, w, h) {
    if (o.c.width !== w || o.c.height !== h) { o.c.width = w; o.c.height = h; }
  }

  /* ---------- setup ---------- */
  function init(canvasEl, overlayEl) {
    canvas = canvasEl;
    ctx = canvas.getContext('2d', { alpha: false });
    supportsFilter = 'filter' in ctx;
    ov = overlayEl;
    ovx = ov ? ov.getContext('2d') : null;
    sa = mk(true); sb = mk(false); sc = mk(false);
    applyAspect();
    bus.on('change', onChange);
    bus.on('selection', requestRender);
    render();
  }

  function applyAspect() {
    var d = RES[S.project.aspect] || RES['16:9'];
    if (canvas.width !== d[0] || canvas.height !== d[1]) {
      canvas.width = d[0]; canvas.height = d[1];
      if (ov) { ov.width = d[0]; ov.height = d[1]; }
      bus.emit('aspect', S.project.aspect);
    }
  }

  function onChange() {
    applyAspect();
    prune();
    syncMedia(time, playing);
    requestRender();
  }

  function requestRender() {
    if (playing || pending) return;
    pending = true;
    requestAnimationFrame(function () { pending = false; render(); });
  }

  /* ---------- media elements ---------- */
  function getEl(tr, c) {
    var key = tr.id + '|' + c.assetId;
    var el = els.get(key);
    if (el) return el;
    var asset = S.assets.get(c.assetId);
    if (!asset) return null;
    el = document.createElement(asset.kind === 'audio' ? 'audio' : 'video');
    el.preload = 'auto';
    el.playsInline = true;
    el.setAttribute('playsinline', '');
    el.src = asset.url;
    el.addEventListener('seeked', requestRender);
    el.addEventListener('loadeddata', requestRender);
    els.set(key, el);
    return el;
  }

  function prune() {
    if (els.size <= 20) return;
    var used = {};
    S.project.tracks.forEach(function (tr) {
      tr.clips.forEach(function (c) { if (OPS.isMedia(c)) used[tr.id + '|' + c.assetId] = true; });
    });
    els.forEach(function (el, key) {
      if (used[key]) return;
      el.pause();
      el.removeAttribute('src');
      try { el.load(); } catch (e) { /* ignore */ }
      els.delete(key);
    });
  }

  function rtime(t) {
    var d = S.duration();
    return d > 0 ? Math.min(t, d - 1e-3) : t;
  }

  function applyEl(el, c, tr, rt, isPlaying) {
    var tau = rt - c.start;
    var asset = S.assets.get(c.assetId);
    var maxT = asset && asset.duration > 0 ? asset.duration - 0.03 : Infinity;
    var want = U.clamp(c.srcIn + SP.srcOffset(c, tau), 0, maxT);
    var silent = tr.hidden || tr.muted;
    el.volume = silent ? 0 : U.clamp(c.audio.volume / 100 * OPS.fadeFactor(c, tau), 0, 1);
    var rate = U.clamp(SP.rateAt(c, tau), 0.0625, 16);
    if (Math.abs(el.playbackRate - rate) > 0.001) el.playbackRate = rate;
    if (isPlaying) {
      if (el.paused) {
        if (Math.abs(el.currentTime - want) > 0.05) el.currentTime = want;
        var p = el.play();
        if (p && p.catch) p.catch(function () { /* autoplay blocked or interrupted */ });
      } else if (Math.abs(el.currentTime - want) > 0.3) {
        el.currentTime = want;
      }
    } else {
      if (!el.paused) el.pause();
      if (Math.abs(el.currentTime - want) > 0.02) el.currentTime = want;
    }
  }

  function syncMedia(t, isPlaying) {
    if (!S.project) return;
    var rt = rtime(t);
    var active = new Map();
    S.project.tracks.forEach(function (tr) {
      tr.clips.forEach(function (c) {
        if (!OPS.isMedia(c)) return;
        if (rt >= c.start - 1e-6 && rt < c.start + c.dur - 1e-6) active.set(tr.id + '|' + c.assetId, { tr: tr, c: c });
      });
    });
    active.forEach(function (v) {
      var el = getEl(v.tr, v.c);
      if (el) applyEl(el, v.c, v.tr, rt, isPlaying);
    });
    els.forEach(function (el, key) { if (!active.has(key) && !el.paused) el.pause(); });
  }

  /* ---------- playback ---------- */
  function resumeCtx() {
    if (!MW.media.audioGraphActive) return;
    var ac = MW.media.getAudioCtx();
    if (ac && ac.state === 'suspended') ac.resume();
  }

  function play() {
    if (playing) return;
    var end = S.duration();
    if (end <= 0) return;
    if (time >= end - 0.02) time = 0;
    playing = true;
    lastNow = performance.now();
    resumeCtx();
    bus.emit('play', true);
    raf = requestAnimationFrame(tick);
  }

  function pause() {
    if (!playing) return;
    playing = false;
    cancelAnimationFrame(raf);
    els.forEach(function (el) { if (!el.paused) el.pause(); });
    syncMedia(time, false);
    bus.emit('play', false);
    requestRender();
  }

  function tick(now) {
    if (!playing) return;
    var dt = Math.min(0.25, (now - lastNow) / 1000);
    lastNow = now;
    time += dt;
    var end = S.duration();
    if (time >= end) {
      time = end;
      render();
      bus.emit('time', time);
      pause();
      bus.emit('ended');
      return;
    }
    syncMedia(time, true);
    render();
    bus.emit('time', time);
    raf = requestAnimationFrame(tick);
  }

  function seek(t) {
    time = Math.max(0, t);
    syncMedia(time, playing);
    if (!playing) requestRender();
    bus.emit('time', time);
  }

  /* ---------- rendering ---------- */
  function render() {
    if (!ctx || !S.project) return;
    var W = canvas.width, H = canvas.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    if (supportsFilter) ctx.filter = 'none';
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, W, H);
    boxes.clear();
    boxOrder = [];
    var rt = rtime(time);
    var tracks = S.project.tracks;
    for (var i = tracks.length - 1; i >= 0; i--) {
      var tr = tracks[i];
      if (tr.type === 'audio' || tr.hidden) continue;
      for (var j = 0; j < tr.clips.length; j++) {
        var c = tr.clips[j];
        if (rt >= c.start - 1e-6 && rt < c.start + c.dur - 1e-6) {
          try { drawClip(tr, c, rt); } catch (e) { if (global.console) console.error(e); }
        }
      }
    }
    boxOrder.reverse();
    drawOverlay();
  }

  function backOut(t) { var c1 = 1.70158, c3 = c1 + 1, u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; }

  function textAnim(c, tau) {
    var t = c.text, d = Math.max(0.05, t.animDur), H = canvas.height;
    var r = { alpha: 1, oy: 0, sMul: 1, blur: 0, reveal: 1 };
    var pin = t.animIn === 'none' ? 1 : U.clamp(tau / d, 0, 1);
    var pout = t.animOut === 'none' ? 1 : U.clamp((c.dur - tau) / d, 0, 1);
    var ein = EASE.easeOut(pin), eout = EASE.easeOut(pout);
    switch (t.animIn) {
      case 'fade': r.alpha *= pin; break;
      case 'slideUp': r.oy += (1 - ein) * H * 0.07; r.alpha *= Math.min(1, pin * 2); break;
      case 'pop': r.sMul *= 0.4 + 0.6 * backOut(pin); r.alpha *= Math.min(1, pin * 3); break;
      case 'typewriter': r.reveal = pin; break;
      case 'blur': r.blur += (1 - pin) * 24; r.alpha *= Math.min(1, pin * 2); break;
    }
    switch (t.animOut) {
      case 'fade': r.alpha *= pout; break;
      case 'slideDown': r.oy += (1 - eout) * H * 0.07; r.alpha *= Math.min(1, pout * 2); break;
      case 'pop': r.sMul *= 0.4 + 0.6 * eout; r.alpha *= Math.min(1, pout * 3); break;
    }
    return r;
  }

  function layoutText(c, maxW) {
    var t = c.text;
    var font = (t.weight >= 600 ? 'bold ' : '') + t.size + 'px "' + t.font + '", sans-serif';
    var g = sb.x;
    g.font = font;
    var lines = [];
    String(t.content || '').split('\n').forEach(function (para) {
      var words = para.split(' '), line = '';
      words.forEach(function (w) {
        var test = line ? line + ' ' + w : w;
        if (line && g.measureText(test).width > maxW) { lines.push(line); line = w; } else line = test;
      });
      lines.push(line);
    });
    var widths = lines.map(function (l) { return g.measureText(l).width; });
    var lineH = t.size * 1.2;
    return { font: font, lines: lines, widths: widths, lineH: lineH, w: Math.max.apply(null, widths.concat([1])), h: lines.length * lineH };
  }

  function filterString(c, extraBlur) {
    var f = c.fx, p = [];
    if (f.brightness !== 100) p.push('brightness(' + f.brightness + '%)');
    if (f.contrast !== 100) p.push('contrast(' + f.contrast + '%)');
    if (f.saturation !== 100) p.push('saturate(' + f.saturation + '%)');
    var b = (f.blur.on ? f.blur.amt : 0) + (extraBlur || 0);
    if (b > 0.05) p.push('blur(' + b.toFixed(1) + 'px)');
    return p.length ? p.join(' ') : 'none';
  }

  /* --- per-source effects on the scratch canvas --- */
  function chromaKey(g, sw, sh, cfg) {
    if (cfg.tol <= 0) return;
    var img = g.getImageData(0, 0, sw, sh), d = img.data, k = U.hexToRgb(cfg.color);
    var kY = 0.299 * k[0] + 0.587 * k[1] + 0.114 * k[2];
    var kCb = -0.169 * k[0] - 0.331 * k[1] + 0.5 * k[2];
    var kCr = 0.5 * k[0] - 0.419 * k[1] - 0.081 * k[2];
    var thr = cfg.tol / 100 * 0.6, feather = 0.12, inv = 1 / 180;
    for (var i = 0; i < d.length; i += 4) {
      var r = d[i], gg = d[i + 1], b = d[i + 2];
      var Y = 0.299 * r + 0.587 * gg + 0.114 * b;
      var cb = -0.169 * r - 0.331 * gg + 0.5 * b;
      var cr = 0.5 * r - 0.419 * gg - 0.081 * b;
      var dc = cb - kCb, dr = cr - kCr, dy = (Y - kY) * 0.25;
      var dist = Math.sqrt(dc * dc + dr * dr + dy * dy) * inv;
      if (dist < thr) d[i + 3] = 0;
      else if (dist < thr + feather) d[i + 3] = (d[i + 3] * (dist - thr) / feather) | 0;
    }
    g.putImageData(img, 0, 0);
  }

  function rgbSplit(sw, sh, amt) {
    var dx = Math.max(1, Math.round(amt / 100 * 0.03 * sw));
    sizeCanvas(sb, sw, sh);
    sizeCanvas(sc, sw, sh);
    var a = sa.x, b = sb.x, c = sc.x;
    c.globalCompositeOperation = 'source-over';
    c.clearRect(0, 0, sw, sh);
    var chans = [['#ff0000', -dx], ['#00ff00', 0], ['#0000ff', dx]];
    chans.forEach(function (ch) {
      b.globalCompositeOperation = 'source-over';
      b.clearRect(0, 0, sw, sh);
      b.drawImage(sa.c, 0, 0);
      b.globalCompositeOperation = 'multiply';
      b.fillStyle = ch[0];
      b.fillRect(0, 0, sw, sh);
      b.globalCompositeOperation = 'destination-in';
      b.drawImage(sa.c, 0, 0);
      c.globalCompositeOperation = 'lighter';
      c.drawImage(sb.c, ch[1], 0);
    });
    a.globalCompositeOperation = 'source-over';
    a.clearRect(0, 0, sw, sh);
    a.drawImage(sc.c, 0, 0);
  }

  function vignette(g, sw, sh, amt) {
    g.save();
    g.globalCompositeOperation = 'source-atop';
    var grad = g.createRadialGradient(sw / 2, sh / 2, Math.min(sw, sh) * 0.22, sw / 2, sh / 2, Math.hypot(sw, sh) / 2);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, 'rgba(0,0,0,' + (amt / 100 * 0.95).toFixed(3) + ')');
    g.fillStyle = grad;
    g.fillRect(0, 0, sw, sh);
    g.restore();
  }

  function processScratch(src, w, h, c) {
    var s = Math.min(1, SCRATCH_MAX / Math.max(w, h));
    var sw = Math.max(2, Math.round(w * s)), sh = Math.max(2, Math.round(h * s));
    sizeCanvas(sa, sw, sh);
    var g = sa.x;
    g.globalCompositeOperation = 'source-over';
    g.clearRect(0, 0, sw, sh);
    g.drawImage(src, 0, 0, sw, sh);
    if (c.chroma.on) chromaKey(g, sw, sh, c.chroma);
    if (c.fx.rgb.on) rgbSplit(sw, sh, c.fx.rgb.amt);
    if (c.fx.vignette.on) vignette(g, sw, sh, c.fx.vignette.amt);
    return sa.c;
  }

  function drawClip(tr, c, rt) {
    var W = canvas.width, H = canvas.height, tau = rt - c.start;
    var x = OPS.evalProp(c, 'x', tau), y = OPS.evalProp(c, 'y', tau);
    var scale = OPS.evalProp(c, 'scale', tau) / 100;
    var rot = OPS.evalProp(c, 'rotation', tau) * Math.PI / 180;
    var alpha = OPS.evalProp(c, 'opacity', tau) / 100;
    var ox = 0, oy = 0, sMul = 1, extraBlur = 0;
    var drawable = null, w = 0, h = 0, layout = null, anim = null;

    if (c.type === 'text') {
      anim = textAnim(c, tau);
      layout = layoutText(c, W * 0.9);
      w = layout.w + c.text.outlineWidth * 2;
      h = layout.h;
      alpha *= anim.alpha; oy = anim.oy; sMul = anim.sMul; extraBlur = anim.blur;
    } else {
      var asset = S.assets.get(c.assetId);
      if (!asset) return;
      if (c.type === 'video') {
        var el = getEl(tr, c);
        if (!el || el.readyState < 2) return;
        drawable = el; w = el.videoWidth; h = el.videoHeight;
      } else {
        drawable = asset.img; w = asset.w; h = asset.h;
      }
      if (!drawable || !w || !h) return;
      if (c.chroma.on || c.fx.rgb.on || c.fx.vignette.on) drawable = processScratch(drawable, w, h, c);
    }

    var fit = layout ? 1 : Math.min(W / w, H / h);
    var dw = w * fit, dh = h * fit, total = scale * sMul;
    var cx = W / 2 + x / 100 * W + ox, cy = H / 2 + y / 100 * H + oy;

    ctx.save();
    ctx.globalAlpha = U.clamp(alpha, 0, 1);
    ctx.globalCompositeOperation = BLEND[c.blend] || 'source-over';
    if (supportsFilter) ctx.filter = filterString(c, extraBlur);
    ctx.translate(cx, cy);
    ctx.rotate(rot);
    ctx.scale(total, total);
    if (layout) drawText(c, layout, anim);
    else ctx.drawImage(drawable, -dw / 2, -dh / 2, dw, dh);
    ctx.restore();

    boxes.set(c.id, { cx: cx, cy: cy, w: dw * total, h: dh * total, rot: rot });
    boxOrder.push(c.id);
  }

  function drawText(c, L, anim) {
    var t = c.text, total = 0, i;
    L.lines.forEach(function (l) { total += l.length; });
    var shown = anim.reveal >= 1 ? total : Math.floor(total * anim.reveal);
    ctx.font = L.font;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    ctx.miterLimit = 2;
    for (i = 0; i < L.lines.length && shown > 0; i++) {
      var str = L.lines[i].slice(0, shown);
      shown -= L.lines[i].length;
      var lx = -L.widths[i] / 2;
      var ly = (i - (L.lines.length - 1) / 2) * L.lineH;
      if (t.outlineWidth > 0) {
        ctx.lineWidth = t.outlineWidth * 2;
        ctx.strokeStyle = t.outlineColor;
        ctx.strokeText(str, lx, ly);
      }
      ctx.fillStyle = t.color;
      ctx.fillText(str, lx, ly);
    }
  }

  function drawOverlay() {
    if (!ovx) return;
    if (ov.width !== canvas.width || ov.height !== canvas.height) { ov.width = canvas.width; ov.height = canvas.height; }
    ovx.clearRect(0, 0, ov.width, ov.height);
    if (exporting) return;
    var id = S.selectedId();
    var b = id && boxes.get(id);
    if (!b) return;
    var lw = Math.max(2, canvas.width / 420), hs = lw * 3;
    ovx.save();
    ovx.translate(b.cx, b.cy);
    ovx.rotate(b.rot);
    ovx.lineWidth = lw;
    ovx.strokeStyle = '#8b6cff';
    ovx.strokeRect(-b.w / 2, -b.h / 2, b.w, b.h);
    ovx.fillStyle = '#ffffff';
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (p) {
      ovx.fillRect(p[0] * b.w / 2 - hs / 2, p[1] * b.h / 2 - hs / 2, hs, hs);
    });
    ovx.restore();
  }

  /* ---------- helpers for the UI ---------- */
  function canvasPoint(clientX, clientY) {
    var r = canvas.getBoundingClientRect();
    return [(clientX - r.left) * canvas.width / r.width, (clientY - r.top) * canvas.height / r.height];
  }

  function hitTest(px, py) {
    for (var i = 0; i < boxOrder.length; i++) {
      var b = boxes.get(boxOrder[i]);
      var dx = px - b.cx, dy = py - b.cy, cs = Math.cos(b.rot), sn = Math.sin(b.rot);
      var lx = dx * cs + dy * sn, ly = -dx * sn + dy * cs;
      if (Math.abs(lx) <= b.w / 2 && Math.abs(ly) <= b.h / 2) return boxOrder[i];
    }
    return null;
  }

  function samplePixel(px, py) {
    render();
    var d = ctx.getImageData(Math.floor(U.clamp(px, 0, canvas.width - 1)), Math.floor(U.clamp(py, 0, canvas.height - 1)), 1, 1).data;
    return U.rgbToHex(d[0], d[1], d[2]);
  }

  /** Route every media element into `dest` (a MediaStreamAudioDestinationNode) for export. */
  function attachExportAudio(dest) {
    var ac = MW.media.getAudioCtx();
    if (!ac) return function () {};
    S.project.tracks.forEach(function (tr) {
      tr.clips.forEach(function (c) { if (OPS.isMedia(c)) getEl(tr, c); });
    });
    var connected = [];
    els.forEach(function (el) {
      if (!el._mwSrc) {
        try { el._mwSrc = ac.createMediaElementSource(el); el._mwSrc.connect(ac.destination); } catch (e) { return; }
      }
      try { el._mwSrc.connect(dest); connected.push(el._mwSrc); } catch (e) { /* ignore */ }
    });
    MW.media.audioGraphActive = true;
    if (ac.resume) ac.resume();
    return function () { connected.forEach(function (s) { try { s.disconnect(dest); } catch (e) { /* ignore */ } }); };
  }

  MW.engine = {
    init: init, play: play, pause: pause, seek: seek, render: render, requestRender: requestRender,
    toggle: function () { playing ? pause() : play(); },
    isPlaying: function () { return playing; },
    getTime: function () { return time; },
    dims: function () { return [canvas.width, canvas.height]; },
    canvasPoint: canvasPoint, hitTest: hitTest, samplePixel: samplePixel,
    attachExportAudio: attachExportAudio,
    setExporting: function (v) { exporting = !!v; render(); },
    get canvas() { return canvas; },
    RES: RES
  };
})(typeof window !== 'undefined' ? window : globalThis);
