/* MiniWare — media.js
 * Importing local files, metadata, thumbnails, audio waveform peaks, sample images.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var U = MW.util, bus = MW.bus;

  var actx = null;
  var peakQueue = Promise.resolve();
  var MAX_PEAK_BYTES = 150 * 1024 * 1024;

  var EXT = {
    video: ['mp4', 'm4v', 'mov', 'webm', 'mkv', 'ogv', '3gp'],
    audio: ['mp3', 'wav', 'ogg', 'oga', 'm4a', 'aac', 'flac', 'opus'],
    image: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'avif']
  };

  function getAudioCtx() {
    if (!actx) {
      var AC = global.AudioContext || global.webkitAudioContext;
      if (!AC) return null;
      try { actx = new AC(); } catch (e) { return null; }
    }
    return actx;
  }

  function kindOf(file) {
    var t = (file.type || '').toLowerCase();
    if (t.indexOf('video/') === 0) return 'video';
    if (t.indexOf('audio/') === 0) return 'audio';
    if (t.indexOf('image/') === 0) return 'image';
    var ext = (file.name.split('.').pop() || '').toLowerCase();
    for (var k in EXT) if (EXT[k].indexOf(ext) >= 0) return k;
    return null;
  }

  function videoInfo(url) {
    return new Promise(function (resolve, reject) {
      var v = document.createElement('video');
      var done = false;
      var info = { duration: 0, w: 0, h: 0, thumb: null };
      function finish(ok) {
        if (done) return;
        done = true;
        v.removeAttribute('src');
        try { v.load(); } catch (e) { /* ignore */ }
        ok ? resolve(info) : reject(new Error('video'));
      }
      v.preload = 'metadata';
      v.muted = true;
      v.playsInline = true;
      v.onerror = function () { finish(false); };
      v.onloadedmetadata = function () {
        info.duration = v.duration;
        info.w = v.videoWidth;
        info.h = v.videoHeight;
        if (!(info.w > 0)) { finish(false); return; }
        try { v.currentTime = Math.min(0.1, (v.duration || 0.2) / 2); } catch (e) { finish(true); }
      };
      v.onseeked = function () {
        try {
          var c = document.createElement('canvas');
          var s = 160 / Math.max(1, v.videoWidth);
          c.width = 160;
          c.height = Math.max(1, Math.round(v.videoHeight * s));
          c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
          info.thumb = c.toDataURL('image/jpeg', 0.6);
        } catch (e) { /* thumbnail is optional */ }
        finish(true);
      };
      setTimeout(function () { if (info.w > 0) finish(true); else finish(false); }, 6000);
      v.src = url;
    });
  }

  function audioInfo(url) {
    return new Promise(function (resolve, reject) {
      var a = new Audio();
      a.preload = 'metadata';
      a.onloadedmetadata = function () { resolve({ duration: a.duration, w: 0, h: 0, thumb: null }); };
      a.onerror = function () { reject(new Error('audio')); };
      a.src = url;
    });
  }

  function imageInfo(url) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () {
        resolve({ duration: 0, w: img.naturalWidth || 1, h: img.naturalHeight || 1, thumb: url, img: img });
      };
      img.onerror = function () { reject(new Error('image')); };
      img.src = url;
    });
  }

  function computePeaks(file, buckets) {
    buckets = buckets || 1200;
    var ctx = getAudioCtx();
    if (!ctx || file.size > MAX_PEAK_BYTES) return Promise.resolve(null);
    return file.arrayBuffer().then(function (buf) {
      return new Promise(function (resolve, reject) {
        var p = ctx.decodeAudioData(buf, resolve, reject);
        if (p && p.catch) p.catch(reject);
      });
    }).then(function (audio) {
      var ch = audio.getChannelData(0);
      var step = Math.max(1, Math.floor(ch.length / buckets));
      var stride = Math.max(1, (step / 48) | 0);
      var peaks = new Float32Array(buckets);
      var gmax = 0.0001;
      for (var i = 0; i < buckets; i++) {
        var s = i * step, e = Math.min(ch.length, s + step), m = 0;
        for (var j = s; j < e; j += stride) { var v = Math.abs(ch[j]); if (v > m) m = v; }
        peaks[i] = m;
        if (m > gmax) gmax = m;
      }
      for (var k = 0; k < buckets; k++) peaks[k] /= gmax;
      return peaks;
    }).catch(function () { return null; });
  }

  function queuePeaks(asset, file) {
    peakQueue = peakQueue.then(function () { return computePeaks(file); }).then(function (peaks) {
      if (peaks) { asset.peaks = peaks; bus.emit('assetupdate', asset); }
    });
  }

  function importFile(file) {
    var kind = kindOf(file);
    if (!kind) { U.toast('Unsupported file: ' + file.name); return Promise.resolve(null); }
    var url = URL.createObjectURL(file);
    var asset = { id: U.uid('asset'), name: file.name, kind: kind, url: url, duration: 0, w: 0, h: 0, thumb: null, peaks: null };
    var p = kind === 'video' ? videoInfo(url) : kind === 'audio' ? audioInfo(url) : imageInfo(url);
    return p.then(function (info) {
      Object.keys(info).forEach(function (k) { asset[k] = info[k]; });
      if (kind !== 'image' && !(asset.duration > 0 && isFinite(asset.duration))) asset.duration = 0;
      MW.store.addAsset(asset);
      if (kind !== 'image') queuePeaks(asset, file);
      return asset;
    }).catch(function () {
      URL.revokeObjectURL(url);
      U.toast('Could not read ' + file.name + ' (format not supported by this browser).');
      return null;
    });
  }

  function importFiles(fileList) {
    var files = Array.prototype.slice.call(fileList || []);
    return files.reduce(function (chain, f) {
      return chain.then(function (acc) { return importFile(f).then(function (a) { if (a) acc.push(a); return acc; }); });
    }, Promise.resolve([]));
  }

  /* ---------- built-in sample images (original artwork, generated on the fly) ---------- */
  function canvasAsset(name, w, h, draw) {
    return new Promise(function (resolve) {
      var c = document.createElement('canvas');
      c.width = w; c.height = h;
      draw(c.getContext('2d'), w, h);
      c.toBlob(function (blob) {
        var url = URL.createObjectURL(blob);
        imageInfo(url).then(function (info) {
          var asset = { id: U.uid('asset'), name: name, kind: 'image', url: url, duration: 0, w: w, h: h, thumb: url, peaks: null };
          Object.keys(info).forEach(function (k) { asset[k] = info[k]; });
          MW.store.addAsset(asset);
          resolve(asset);
        });
      }, 'image/png');
    });
  }

  function addSamples() {
    var a = canvasAsset('Sample gradient.png', 1280, 720, function (x, w, h) {
      var g = x.createLinearGradient(0, 0, w, h);
      g.addColorStop(0, '#1d2671'); g.addColorStop(0.55, '#7c3aed'); g.addColorStop(1, '#f97362');
      x.fillStyle = g; x.fillRect(0, 0, w, h);
      x.globalAlpha = 0.18; x.fillStyle = '#fff';
      for (var i = 0; i < 14; i++) { x.beginPath(); x.arc((i * 211) % w, (i * 137) % h, 40 + (i * 23) % 120, 0, Math.PI * 2); x.fill(); }
      x.globalAlpha = 1;
    });
    var b = canvasAsset('Sample green screen.png', 1280, 720, function (x, w, h) {
      x.fillStyle = '#00ff00'; x.fillRect(0, 0, w, h);
      x.fillStyle = '#ffb703'; x.beginPath(); x.arc(w / 2, h / 2, 210, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#e63946'; x.beginPath(); x.arc(w / 2, h / 2, 130, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#fff'; x.font = 'bold 120px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillText('MW', w / 2, h / 2 + 6);
    });
    return Promise.all([a, b]);
  }

  /* ---------- custom fonts (FontFace API) ---------- */
  var fonts = ['Arial', 'Georgia', 'Impact', 'Courier New', 'Trebuchet MS', 'Verdana', 'Times New Roman', 'Comic Sans MS'];

  function loadFont(file) {
    var name = file.name.replace(/\.[^.]+$/, '').replace(/[^\w \-]/g, '').trim() || 'Custom font';
    return file.arrayBuffer().then(function (buf) {
      var face = new FontFace(name, buf);
      return face.load().then(function () {
        document.fonts.add(face);
        if (fonts.indexOf(name) < 0) fonts.push(name);
        bus.emit('fonts');
        return name;
      });
    });
  }

  MW.media = {
    getAudioCtx: getAudioCtx,
    audioGraphActive: false,
    importFiles: importFiles,
    addSamples: addSamples,
    loadFont: loadFont,
    fonts: fonts
  };
})(typeof window !== 'undefined' ? window : globalThis);
