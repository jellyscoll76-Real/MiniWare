/* MiniWare — easing.js
 * Easing curves + keyframe interpolation helpers.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});

  function bounceOut(t) {
    var n1 = 7.5625, d1 = 2.75;
    if (t < 1 / d1) return n1 * t * t;
    if (t < 2 / d1) { t -= 1.5 / d1; return n1 * t * t + 0.75; }
    if (t < 2.5 / d1) { t -= 2.25 / d1; return n1 * t * t + 0.9375; }
    t -= 2.625 / d1; return n1 * t * t + 0.984375;
  }

  var fns = {
    linear: function (t) { return t; },
    easeIn: function (t) { return t * t * t; },
    easeOut: function (t) { var u = 1 - t; return 1 - u * u * u; },
    easeInOut: function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; },
    bounce: bounceOut,
    elastic: function (t) {
      if (t <= 0) return 0;
      if (t >= 1) return 1;
      return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1;
    },
    /* decaying wobble that starts and ends exactly on target */
    shake: function (t) { return t + Math.sin(t * Math.PI * 12) * 0.14 * Math.sin(t * Math.PI); },
    hold: function (t) { return t >= 1 ? 1 : 0; }
  };

  var list = [
    ['linear', 'Linear'], ['easeIn', 'Ease In'], ['easeOut', 'Ease Out'], ['easeInOut', 'Ease In-Out'],
    ['bounce', 'Bounce'], ['elastic', 'Elastic'], ['shake', 'Shake'], ['hold', 'Hold (step)']
  ];

  function get(name) { return fns[name] || fns.linear; }

  MW.easing = { fns: fns, list: list, get: get };

  /* ---------- keyframes ----------
   * A keyframe list is an array sorted by t: [{t, v, ease}]
   * `ease` shapes the segment that starts at this keyframe.
   */
  var KF_EPS = 0.04; // seconds: keyframes closer than this are treated as the same

  function valueAt(kfs, t, base) {
    if (!kfs || !kfs.length) return base;
    if (t <= kfs[0].t) return kfs[0].v;
    var last = kfs[kfs.length - 1];
    if (t >= last.t) return last.v;
    for (var i = 0; i < kfs.length - 1; i++) {
      var a = kfs[i], b = kfs[i + 1];
      if (t < b.t) {
        var u = (t - a.t) / (b.t - a.t);
        return a.v + (b.v - a.v) * get(a.ease)(u);
      }
    }
    return last.v;
  }

  function indexNear(kfs, t, eps) {
    eps = eps == null ? KF_EPS : eps;
    for (var i = 0; i < kfs.length; i++) if (Math.abs(kfs[i].t - t) < eps) return i;
    return -1;
  }

  function upsert(kfs, t, v, ease) {
    var i = indexNear(kfs, t);
    if (i >= 0) {
      kfs[i].v = v;
      if (ease) kfs[i].ease = ease;
      return kfs[i];
    }
    var k = { t: Math.round(t * 1000) / 1000, v: v, ease: ease || 'easeInOut' };
    kfs.push(k);
    kfs.sort(function (a, b) { return a.t - b.t; });
    return k;
  }

  function removeNear(kfs, t) {
    var i = indexNear(kfs, t);
    if (i >= 0) kfs.splice(i, 1);
    return i >= 0;
  }

  MW.anim = { KF_EPS: KF_EPS, valueAt: valueAt, indexNear: indexNear, upsert: upsert, removeNear: removeNear };
})(typeof window !== 'undefined' ? window : globalThis);
