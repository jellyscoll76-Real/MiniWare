/* MiniWare — speed.js
 * Constant speed (0.2x – 5x) plus speed-curve presets (speed ramping).
 *
 * A clip maps timeline time `tau` (seconds from clip start) to source time with
 *   S(tau) = speed * (M(cu0 + r*tau) - M(cu0)) / r,   r = (cu1 - cu0) / dur
 * where M is the integral of the curve multiplier m(u) over normalized curve time u.
 * cu0/cu1 track which slice of the curve a (split/trimmed) clip is using, so
 * splitting a ramped clip keeps the ramp continuous.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var N = 256;

  var presets = {
    none:     { label: 'None (constant)',      m: function () { return 1; } },
    speedUp:  { label: 'Slow → Fast',          m: function (u) { return 0.25 + 1.75 * u; } },
    slowDown: { label: 'Fast → Slow',          m: function (u) { return 2 - 1.75 * u; } },
    pulse:    { label: 'Fast · Slow · Fast',   m: function (u) { var d = 2 * u - 1; return 0.3 + 1.7 * d * d; } },
    bullet:   { label: 'Slow · Fast · Slow',   m: function (u) { var d = 2 * u - 1; return 2.0 - 1.7 * d * d; } }
  };
  var order = ['none', 'speedUp', 'slowDown', 'pulse', 'bullet'];
  var tables = {};

  function preset(id) { return presets[id] || presets.none; }

  function table(id) {
    if (!tables[id]) {
      var f = preset(id).m, T = new Float64Array(N + 1), acc = 0, prev = f(0);
      for (var i = 1; i <= N; i++) {
        var cur = f(i / N);
        acc += (prev + cur) / 2 / N;
        T[i] = acc;
        prev = cur;
      }
      tables[id] = T;
    }
    return tables[id];
  }

  function mult(id, u) {
    return preset(id).m(Math.min(1, Math.max(0, u)));
  }

  /** Integral of the multiplier from 0 to u (extended linearly outside [0,1]). */
  function M(id, u) {
    if (!id || id === 'none' || !presets[id]) return u;
    if (u <= 0) return u * mult(id, 0);
    if (u >= 1) return table(id)[N] + (u - 1) * mult(id, 1);
    var x = u * N, i = Math.floor(x), fr = x - i, T = table(id);
    return T[i] + (T[Math.min(i + 1, N)] - T[i]) * fr;
  }

  function rate(clip) { return (clip.cu1 - clip.cu0) / Math.max(clip.dur, 1e-6); }

  /** Source seconds consumed after `tau` timeline seconds. */
  function srcOffset(clip, tau) {
    var r = rate(clip);
    if (!(r > 0)) return clip.speed * tau;
    var id = clip.curve || 'none';
    return clip.speed * (M(id, clip.cu0 + r * tau) - M(id, clip.cu0)) / r;
  }

  function srcSpan(clip) { return srcOffset(clip, clip.dur); }

  /** Timeline duration needed so the clip consumes `span` source seconds. */
  function durForSpan(clip, span) {
    var id = clip.curve || 'none';
    var du = clip.cu1 - clip.cu0;
    var dM = M(id, clip.cu1) - M(id, clip.cu0);
    if (!(du > 0) || !(dM > 0)) return span / Math.max(clip.speed, 0.01);
    return span * du / (clip.speed * dM);
  }

  /** Instantaneous playback rate at `tau`. */
  function rateAt(clip, tau) {
    return clip.speed * mult(clip.curve || 'none', clip.cu0 + rate(clip) * tau);
  }

  /** Curve samples for the inspector graph. */
  function sample(id, n) {
    var out = [];
    for (var i = 0; i <= n; i++) out.push(mult(id, i / n));
    return out;
  }

  MW.speed = {
    MIN: 0.2, MAX: 5,
    presets: presets, order: order,
    mult: mult, M: M, rate: rate, srcOffset: srcOffset, srcSpan: srcSpan,
    durForSpan: durForSpan, rateAt: rateAt, sample: sample
  };
})(typeof window !== 'undefined' ? window : globalThis);
