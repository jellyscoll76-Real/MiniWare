/* MiniWare — inspector.js
 * Right-hand panel: edits the selected clip (transform + keyframes, speed, blend/chroma,
 * text, filters/FX, audio). Built once per selection, values refreshed on every change.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var U = MW.util, h = U.h, S = MW.store, OPS = MW.clipops, SP = MW.speed, E = MW.engine, A = MW.anim, bus = MW.bus;

  var BLENDS = [['normal', 'Normal'], ['screen', 'Screen'], ['multiply', 'Multiply'], ['overlay', 'Overlay']];
  var ANIM_IN = [['none', 'None'], ['fade', 'Fade in'], ['slideUp', 'Slide up'], ['pop', 'Pop'], ['typewriter', 'Typewriter'], ['blur', 'Blur in']];
  var ANIM_OUT = [['none', 'None'], ['fade', 'Fade out'], ['slideDown', 'Slide down'], ['pop', 'Shrink']];
  var DIAMOND = '<svg viewBox="0 0 24 24"><path d="M12 3l9 9-9 9-9-9z"/></svg>';

  var root = null, curId = null, builtId = null;
  var bindings = [];
  var openState = {};
  var lastEase = 'easeInOut', shakeAmt = 1;

  /* ---------- small helpers ---------- */
  function cur() { var f = curId && S.find(curId); return f ? f.clip : null; }
  function tauOf(c) { return U.clamp(E.getTime() - c.start, 0, c.dur); }
  function bind(refresh, time) { bindings.push({ refresh: refresh, time: !!time }); }
  function mut(fn, key) { S.mutateClip(curId, fn, key ? key + ':' + curId : null); }

  function sec(title, children) {
    var d = h('details', { class: 'sec' }, h('summary', null, title), h('div', { class: 'sec-body' }, children));
    d.open = openState[title] !== false;
    d.addEventListener('toggle', function () { openState[title] = d.open; });
    return d;
  }
  function field(label, control) {
    return h('div', { class: 'field' }, label ? h('label', null, label) : null, control);
  }
  function btn(text, onclick, cls, title) {
    return h('button', { type: 'button', class: 'btn ' + (cls || ''), onclick: onclick, title: title || null }, text);
  }

  function select(options, get, set, time) {
    var s = h('select', null, options.map(function (o) { return h('option', { value: o[0] }, o[1]); }));
    s.addEventListener('change', function () { set(s.value); });
    bind(function (c) { s.value = get(c); }, time);
    return s;
  }

  function colorInput(get, set) {
    var i = h('input', { type: 'color' });
    i.addEventListener('input', function () { set(i.value); });
    bind(function (c) { i.value = get(c); });
    return i;
  }

  function toggle(label, get, set) {
    var i = h('input', { type: 'checkbox' });
    i.addEventListener('change', function () { set(i.checked); });
    bind(function (c) { i.checked = !!get(c); });
    return h('label', { class: 'check' }, i, h('span', null, label));
  }

  /** slider + number box. o: {min,max,step,get(c),write(v),fmt,time} */
  function slider(o) {
    var input = h('input', { type: 'range', min: o.min, max: o.max, step: o.step || 1 });
    var num = h('input', { type: 'number', class: 'num', min: o.min, max: o.max, step: o.step || 1 });
    var toSlider = o.toSlider || function (v) { return v; };
    var fromSlider = o.fromSlider || function (v) { return v; };
    input.addEventListener('input', function () {
      var v = o.round ? o.round(fromSlider(parseFloat(input.value))) : fromSlider(parseFloat(input.value));
      o.write(v);
    });
    num.addEventListener('change', function () {
      var v = parseFloat(num.value);
      if (isNaN(v)) return;
      o.write(U.clamp(v, o.numMin != null ? o.numMin : o.min, o.numMax != null ? o.numMax : o.max));
    });
    bind(function (c) {
      var v = o.get(c);
      input.value = toSlider(v);
      if (document.activeElement !== num) num.value = U.round(v, 2);
    }, o.time);
    return h('div', { class: 'ctl-line' }, input, num);
  }

  function fld(label, min, max, step, get, set, key) {
    return field(label, slider({
      min: min, max: max, step: step, get: get,
      write: function (v) { mut(function (c) { set(c, v); }, key || label); }
    }));
  }

  /* ---------- keyframed property row ---------- */
  function propRow(label, prop, min, max, step) {
    var kb = h('button', { type: 'button', class: 'kf', title: 'Add / remove keyframe at playhead' });
    kb.innerHTML = DIAMOND;
    kb.addEventListener('click', function () {
      var c = cur();
      if (c) S.toggleKeyframe(curId, prop, tauOf(c));
    });
    bind(function (c) {
      var kfs = c.kf[prop];
      kb.classList.toggle('has', kfs.length > 0);
      kb.classList.toggle('on', A.indexNear(kfs, tauOf(c)) >= 0);
    }, true);
    var sl = slider({
      min: min, max: max, step: step, time: true,
      get: function (c) { return OPS.evalProp(c, prop, tauOf(c)); },
      write: function (v) {
        var c = cur(), vals = {};
        if (!c) return;
        vals[prop] = v;
        S.setProps(curId, vals, tauOf(c), 'p:' + curId + ':' + prop);
      }
    });
    return h('div', { class: 'field kfrow' }, h('label', null, label), h('div', { class: 'kfwrap' }, sl, kb));
  }

  /* ---------- sections ---------- */
  function transformSection(c) {
    var kids = [
      propRow('Position X', 'x', -100, 100, 0.1),
      propRow('Position Y', 'y', -100, 100, 0.1),
      propRow('Scale', 'scale', 5, 400, 1),
      propRow('Rotation', 'rotation', -360, 360, 0.5),
      propRow('Opacity', 'opacity', 0, 100, 1)
    ];
    if (c.type !== 'text') {
      var fit = function (fill) {
        var cc = cur(), a = cc && S.assets.get(cc.assetId);
        if (!a || !a.w) return;
        var d = E.dims(), kFit = Math.min(d[0] / a.w, d[1] / a.h), kFill = Math.max(d[0] / a.w, d[1] / a.h);
        S.setProps(curId, { scale: fill ? Math.round(100 * kFill / kFit) : 100, x: 0, y: 0 }, tauOf(cc), null);
      };
      kids.push(h('div', { class: 'btnrow' },
        btn('Fit', function () { fit(false); }, '', 'Fit inside the frame'),
        btn('Fill', function () { fit(true); }, '', 'Fill the frame (crops edges)')));
    }
    return sec('Transform', kids);
  }

  function keyframeSection() {
    var easeSel = select(MW.easing.list, function (c) {
      var t = tauOf(c);
      for (var i = 0; i < OPS.PROPS.length; i++) {
        var kfs = c.kf[OPS.PROPS[i]], j = A.indexNear(kfs, t);
        if (j >= 0) return kfs[j].ease;
      }
      return lastEase;
    }, function (v) {
      lastEase = v;
      var c = cur();
      if (c) S.setKeyEase(curId, tauOf(c), v);
    }, true);

    function jump(dir) {
      var c = cur();
      if (!c) return;
      var t = tauOf(c), ts = OPS.allKfTimes(c), target = null, i;
      if (dir > 0) { for (i = 0; i < ts.length; i++) if (ts[i] > t + 0.02) { target = ts[i]; break; } }
      else { for (i = ts.length - 1; i >= 0; i--) if (ts[i] < t - 0.02) { target = ts[i]; break; } }
      if (target != null) E.seek(c.start + target);
    }

    var shake = slider({
      min: 0.5, max: 3, step: 0.1, get: function () { return shakeAmt; },
      write: function (v) { shakeAmt = v; }
    });

    return sec('Keyframes & Easing', [
      h('p', { class: 'hint' }, 'Click a ◆ next to a property (or Add Key) at the playhead. Once a property has keyframes, moving a slider keys it automatically.'),
      field('Easing into next keyframe', easeSel),
      h('div', { class: 'btnrow' },
        btn('◀ Prev', function () { jump(-1); }),
        btn('◆ Add key', function () { var c = cur(); if (c) S.addKeyframesAll(curId, tauOf(c), lastEase); }, 'accent'),
        btn('Next ▶', function () { jump(1); })),
      field('Shake strength', shake),
      h('div', { class: 'btnrow' },
        btn('Add shake burst', function () { var c = cur(); if (c) S.addShake(curId, tauOf(c), 0.6, shakeAmt); }, '', 'Adds a decaying shake on X, Y and rotation at the playhead'),
        btn('Clear keys', function () { var c = cur(); if (c) S.clearKeyframes(curId, tauOf(c)); }))
    ]);
  }

  function speedSection() {
    var LOG = Math.log(SP.MAX / SP.MIN);
    var sl = slider({
      min: 0, max: 100, step: 1, numMin: SP.MIN, numMax: SP.MAX,
      toSlider: function (v) { return 100 * Math.log(Math.max(SP.MIN, v) / SP.MIN) / LOG; },
      fromSlider: function (v) { return SP.MIN * Math.exp(LOG * v / 100); },
      round: function (v) { v = Math.round(v * 100) / 100; return Math.abs(v - 1) < 0.04 ? 1 : v; },
      get: function (c) { return c.speed; },
      write: function (v) { S.retime(curId, { speed: U.clamp(v, SP.MIN, SP.MAX) }, 'speed'); }
    });
    var chips = h('div', { class: 'chips' }, [0.2, 0.5, 1, 2, 3, 5].map(function (v) {
      return btn(v + '×', function () { S.retime(curId, { speed: v }); }, 'chip');
    }));
    var curveSel = select(SP.order.map(function (id) { return [id, SP.presets[id].label]; }),
      function (c) { return c.curve; },
      function (v) { S.retime(curId, { curve: v }); });
    var cv = h('canvas', { class: 'curve', width: 260, height: 56 });
    var info = h('div', { class: 'hint' });
    bind(function (c) {
      var g = cv.getContext('2d'), w = cv.width, hh = cv.height;
      g.clearRect(0, 0, w, hh);
      var maxM = 2.2;
      g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1; g.setLineDash([3, 3]);
      g.beginPath(); g.moveTo(0, hh - hh / maxM * c.speed); g.lineTo(w, hh - hh / maxM * c.speed); g.stroke();
      g.setLineDash([]);
      g.strokeStyle = '#8b6cff'; g.lineWidth = 2; g.beginPath();
      var pts = SP.sample(c.curve, 60);
      pts.forEach(function (m, i) {
        var y = hh - U.clamp(m * c.speed / maxM, 0, 1.2) * hh * 0.98 - 1;
        var x = i / 60 * w;
        i ? g.lineTo(x, y) : g.moveTo(x, y);
      });
      g.stroke();
      info.textContent = 'Clip length ' + U.round(c.dur, 2) + 's · source ' + U.round(SP.srcSpan(c), 2) + 's';
    });
    return sec('Speed & Ramping', [
      field('Speed (0.2× – 5×)', sl), chips,
      field('Speed curve', curveSel),
      cv, info
    ]);
  }

  function blendSection(c) {
    var kids = [field('Blend mode', select(BLENDS, function (c2) { return c2.blend; }, function (v) { mut(function (x) { x.blend = v; }); }))];
    if (c.type !== 'text') {
      kids.push(h('div', { class: 'divider' }));
      kids.push(toggle('Chroma key (green screen)', function (x) { return x.chroma.on; }, function (v) { mut(function (x) { x.chroma.on = v; }); }));
      kids.push(h('div', { class: 'field inline' },
        h('label', null, 'Key color'),
        colorInput(function (x) { return x.chroma.color; }, function (v) { mut(function (x) { x.chroma.color = v; }, 'ck'); }),
        btn('Pick from preview', function () {
          U.toast('Click the color to remove in the preview');
          MW.ui.pickColor(function (hex) { mut(function (x) { x.chroma.color = hex; x.chroma.on = true; }); });
        })));
      kids.push(fld('Tolerance', 0, 100, 1, function (x) { return x.chroma.tol; }, function (x, v) { x.chroma.tol = v; }, 'tol'));
    }
    return sec(c.type === 'text' ? 'Blend' : 'Blend & Chroma Key', kids);
  }

  function textSection() {
    var ta = h('textarea', { rows: 3, spellcheck: 'false' });
    ta.addEventListener('input', function () { mut(function (x) { x.text.content = ta.value; }, 'txt'); });
    bind(function (c) { if (document.activeElement !== ta) ta.value = c.text.content; });

    var fontSel = h('select', null, MW.media.fonts.map(function (f) { return h('option', { value: f }, f); }));
    fontSel.addEventListener('change', function () { mut(function (x) { x.text.font = fontSel.value; }); });
    bind(function (c) { fontSel.value = c.text.font; });

    var file = h('input', { type: 'file', accept: '.ttf,.otf,.woff,.woff2', class: 'hidden' });
    file.addEventListener('change', function () {
      var f = file.files && file.files[0];
      file.value = '';
      if (!f) return;
      MW.media.loadFont(f).then(function (name) { mut(function (x) { x.text.font = name; }); build(); })
        .catch(function () { U.toast('Could not load that font file.'); });
    });

    return sec('Text & Captions', [
      field('Content', ta),
      field('Font', h('div', { class: 'ctl-line' }, fontSel, btn('Upload…', function () { file.click(); }), file)),
      fld('Size', 12, 240, 1, function (x) { return x.text.size; }, function (x, v) { x.text.size = v; }, 'size'),
      h('div', { class: 'field inline' },
        toggle('Bold', function (x) { return x.text.weight >= 600; }, function (v) { mut(function (x) { x.text.weight = v ? 700 : 400; }); }),
        h('label', null, 'Fill'), colorInput(function (x) { return x.text.color; }, function (v) { mut(function (x) { x.text.color = v; }, 'tc'); }),
        h('label', null, 'Outline'), colorInput(function (x) { return x.text.outlineColor; }, function (v) { mut(function (x) { x.text.outlineColor = v; }, 'oc'); })),
      fld('Outline width', 0, 24, 1, function (x) { return x.text.outlineWidth; }, function (x, v) { x.text.outlineWidth = v; }, 'ow'),
      field('Entrance animation', select(ANIM_IN, function (x) { return x.text.animIn; }, function (v) { mut(function (x) { x.text.animIn = v; }); })),
      field('Exit animation', select(ANIM_OUT, function (x) { return x.text.animOut; }, function (v) { mut(function (x) { x.text.animOut = v; }); })),
      fld('Animation length (s)', 0.1, 2, 0.05, function (x) { return x.text.animDur; }, function (x, v) { x.text.animDur = v; }, 'ad')
    ]);
  }

  function fxToggle(label, key, max, step) {
    var sl = slider({
      min: 0, max: max, step: step,
      get: function (c) { return c.fx[key].amt; },
      write: function (v) { mut(function (x) { x.fx[key].amt = v; }, 'fx' + key); }
    });
    return h('div', { class: 'field' },
      toggle(label, function (c) { return c.fx[key].on; }, function (v) { mut(function (x) { x.fx[key].on = v; }); }),
      sl);
  }

  function filterSection(c) {
    var kids = [
      fld('Brightness', 0, 200, 1, function (x) { return x.fx.brightness; }, function (x, v) { x.fx.brightness = v; }, 'br'),
      fld('Contrast', 0, 200, 1, function (x) { return x.fx.contrast; }, function (x, v) { x.fx.contrast = v; }, 'co'),
      fld('Saturation', 0, 200, 1, function (x) { return x.fx.saturation; }, function (x, v) { x.fx.saturation = v; }, 'sa'),
      h('div', { class: 'divider' }),
      fxToggle('Gaussian blur', 'blur', 40, 0.5)
    ];
    if (c.type !== 'text') {
      kids.push(fxToggle('Chromatic aberration / RGB split', 'rgb', 100, 1));
      kids.push(fxToggle('Vignette', 'vignette', 100, 1));
    }
    return sec('Filters & Glitch FX', kids);
  }

  function audioSection() {
    return sec('Audio', [
      fld('Volume', 0, 100, 1, function (x) { return x.audio.volume; }, function (x, v) { x.audio.volume = v; }, 'vol'),
      fld('Fade in (s)', 0, 5, 0.1, function (x) { return x.audio.fadeIn; }, function (x, v) { x.audio.fadeIn = v; }, 'fi'),
      fld('Fade out (s)', 0, 5, 0.1, function (x) { return x.audio.fadeOut; }, function (x, v) { x.audio.fadeOut = v; }, 'fo')
    ]);
  }

  /* ---------- build / refresh ---------- */
  function build() {
    if (!root) return;
    bindings = [];
    var c = S.selected();
    curId = c ? c.id : null;
    builtId = curId;
    root.innerHTML = '';
    if (!c) {
      root.appendChild(h('div', { class: 'empty' },
        h('div', { class: 'empty-title' }, 'Nothing selected'),
        h('p', null, 'Click a clip on the timeline (or in the preview) to edit it here.'),
        h('p', { class: 'hint' }, 'Tip: import media on the left, drag it onto a track, then press Space to play.')));
      return;
    }
    var typeLabel = { video: 'Video', image: 'Image', audio: 'Audio', text: 'Text' }[c.type];
    var nameIn = h('input', { type: 'text', class: 'name', maxlength: 60 });
    nameIn.addEventListener('input', function () { mut(function (x) { x.name = nameIn.value; }, 'name'); });
    bind(function (cc) { if (document.activeElement !== nameIn) nameIn.value = cc.name; });
    root.appendChild(h('div', { class: 'clip-head' }, h('span', { class: 'badge t-' + c.type }, typeLabel), nameIn));

    var visual = c.type !== 'audio';
    var media = c.type === 'video' || c.type === 'audio';
    if (c.type === 'text') root.appendChild(textSection());
    if (visual) root.appendChild(transformSection(c));
    if (visual) root.appendChild(keyframeSection());
    if (media) root.appendChild(speedSection());
    if (visual) root.appendChild(blendSection(c));
    if (visual) root.appendChild(filterSection(c));
    if (media) root.appendChild(audioSection());
    refresh();
  }

  function refresh() {
    var c = cur();
    if (!c) return;
    bindings.forEach(function (b) { b.refresh(c); });
  }

  function onChange() {
    var c = S.selected();
    if ((c ? c.id : null) !== builtId) build(); else refresh();
  }

  function onTime() {
    var c = cur();
    if (!c || !OPS.hasKf(c)) return;
    bindings.forEach(function (b) { if (b.time) b.refresh(c); });
  }

  MW.inspector = {
    init: function (el) {
      root = el;
      bus.on('selection', build);
      bus.on('change', onChange);
      bus.on('time', onTime);
      build();
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
