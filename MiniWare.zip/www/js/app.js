/* MiniWare — app.js
 * Bootstraps the editor: media bin, transport, toolbar, shortcuts, preview interaction, export UI.
 */
(function (global) {
  'use strict';
  var MW = global.MW;
  var U = MW.util, h = U.h, S = MW.store, E = MW.engine, OPS = MW.clipops, bus = MW.bus;
  var $ = function (id) { return document.getElementById(id); };

  var ICON_PLAY = '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/></svg>';
  var ICON_PAUSE = '<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z" fill="currentColor" stroke="none"/></svg>';
  var ICON_NOTE = '<svg viewBox="0 0 24 24"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>';

  var app = $('app'), stageArea = $('stageArea'), stage = $('stage');
  var pickCb = null;

  /* ---------- boot ---------- */
  S.init();
  E.init($('preview'), $('overlay'));
  MW.timeline.init($('tlScroll'));
  MW.inspector.init($('inspector'));

  /* ---------- stage sizing ---------- */
  function fitStage() {
    var r = stageArea.getBoundingClientRect(), d = E.dims(), pad = 14;
    var k = Math.min((r.width - pad * 2) / d[0], (r.height - pad * 2) / d[1]);
    if (!(k > 0)) return;
    stage.style.width = Math.floor(d[0] * k) + 'px';
    stage.style.height = Math.floor(d[1] * k) + 'px';
  }
  bus.on('aspect', fitStage);
  if (global.ResizeObserver) new ResizeObserver(fitStage).observe(stageArea);
  global.addEventListener('resize', fitStage);
  fitStage();

  /* ---------- media bin ---------- */
  var binList = $('binList');

  function addAssetToTimeline(id) {
    S.mutate(function () { S.addAssetClip(id, { start: E.getTime() }); });
  }

  function renderBin() {
    binList.innerHTML = '';
    if (!S.assets.size) {
      binList.appendChild(h('div', { class: 'bin-empty' },
        h('p', null, 'No media yet.'),
        h('p', { class: 'hint' }, 'Import video, audio or images — or drop files here. Files stay on your device.')));
      return;
    }
    S.assets.forEach(function (a) {
      var thumb = h('div', { class: 'asset-thumb t-' + a.kind });
      if (a.kind === 'audio') thumb.innerHTML = ICON_NOTE;
      else if (a.thumb) thumb.style.backgroundImage = 'url("' + a.thumb + '")';
      var add = h('button', { class: 'mini add', type: 'button', title: 'Add to timeline at the playhead', onclick: function (e) { e.stopPropagation(); addAssetToTimeline(a.id); } }, '+');
      binList.appendChild(h('div', {
        class: 'asset', draggable: 'true', title: a.name + ' — double-click to add',
        ondragstart: function (e) {
          e.dataTransfer.setData('text/miniware-asset', a.id);
          e.dataTransfer.effectAllowed = 'copy';
        },
        ondblclick: function () { addAssetToTimeline(a.id); }
      }, thumb,
      h('div', { class: 'asset-info' },
        h('div', { class: 'asset-name' }, a.name),
        h('div', { class: 'asset-meta' }, a.kind + (a.duration > 0 ? ' · ' + U.fmtDur(a.duration) : '') + (a.w ? ' · ' + a.w + '×' + a.h : ''))),
      add));
    });
  }
  bus.on('assets', renderBin);
  renderBin();

  var fileInput = $('fileInput');
  $('btnImport').addEventListener('click', function () { fileInput.click(); });
  fileInput.addEventListener('change', function () {
    MW.media.importFiles(fileInput.files);
    fileInput.value = '';
  });
  $('btnSample').addEventListener('click', function () { MW.media.addSamples(); });
  $('btnAddText').addEventListener('click', function () {
    S.mutate(function () { S.addTextClip(E.getTime()); });
    app.dataset.tab = 'inspector';
  });

  // drop files anywhere on the page
  global.addEventListener('dragover', function (e) {
    if (e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0) e.preventDefault();
  });
  global.addEventListener('drop', function (e) {
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
      e.preventDefault();
      MW.media.importFiles(e.dataTransfer.files);
    }
  });

  /* ---------- transport ---------- */
  var btnPlay = $('btnPlay'), timecode = $('timecode');
  btnPlay.innerHTML = ICON_PLAY;
  btnPlay.addEventListener('click', function () { E.toggle(); });
  function updateTimecode() {
    timecode.textContent = U.fmtTime(E.getTime()) + ' / ' + U.fmtTime(S.duration());
  }
  bus.on('time', updateTimecode);
  bus.on('play', function (p) { btnPlay.innerHTML = p ? ICON_PAUSE : ICON_PLAY; btnPlay.classList.toggle('on', p); });

  var aspectBtns = document.querySelectorAll('[data-aspect]');
  Array.prototype.forEach.call(aspectBtns, function (b) {
    b.addEventListener('click', function () {
      var a = b.getAttribute('data-aspect');
      if (S.project.aspect !== a) S.mutate(function (p) { p.aspect = a; });
    });
  });

  /* ---------- timeline toolbar ---------- */
  var btnUndo = $('btnUndo'), btnRedo = $('btnRedo');
  function syncToolbar() {
    btnUndo.disabled = !S.canUndo();
    btnRedo.disabled = !S.canRedo();
    $('btnDelete').disabled = !S.selected();
    Array.prototype.forEach.call(aspectBtns, function (b) {
      b.classList.toggle('on', b.getAttribute('data-aspect') === S.project.aspect);
    });
    updateTimecode();
  }
  bus.on('change', syncToolbar);
  bus.on('selection', syncToolbar);
  syncToolbar();

  function doSplit() {
    var t = E.getTime();
    if (!S.canSplit(t)) { U.toast('Move the playhead over a clip to split it.'); return; }
    S.mutate(function () { S.splitAt(t); });
  }
  function doDelete() {
    if (S.selected()) S.mutate(function () { S.deleteSelected(); });
  }
  btnUndo.addEventListener('click', function () { S.undo(); });
  btnRedo.addEventListener('click', function () { S.redo(); });
  $('btnSplit').addEventListener('click', doSplit);
  $('btnDelete').addEventListener('click', doDelete);

  var addTrack = $('selAddTrack');
  addTrack.addEventListener('change', function () {
    var v = addTrack.value;
    addTrack.value = '';
    if (v) S.mutate(function () { S.addTrack(v); });
  });

  var zoom = $('zoom');
  zoom.value = MW.timeline.sliderValue();
  zoom.addEventListener('input', function () { MW.timeline.setSliderValue(parseFloat(zoom.value)); });
  bus.on('zoom', function () { zoom.value = MW.timeline.sliderValue(); });
  $('chkSnap').addEventListener('change', function (e) { MW.timeline.setSnap(e.target.checked); });

  /* ---------- keyboard ---------- */
  global.addEventListener('keydown', function (e) {
    var tag = (e.target.tagName || '').toLowerCase(), type = e.target.type;
    var typing = tag === 'textarea' || tag === 'select' ||
      (tag === 'input' && type !== 'range' && type !== 'checkbox' && type !== 'color' && type !== 'button');
    var mod = e.ctrlKey || e.metaKey, k = e.key;
    if (k === 'Escape' && pickCb) { pickCb = null; stage.classList.remove('picking'); return; }
    if (mod && (k === 'z' || k === 'Z')) { if (typing) return; e.preventDefault(); e.shiftKey ? S.redo() : S.undo(); return; }
    if (mod && (k === 'y' || k === 'Y')) { if (typing) return; e.preventDefault(); S.redo(); return; }
    if (typing || mod || e.altKey) return;
    if (tag === 'button' && k === ' ') return;
    switch (k) {
      case ' ': e.preventDefault(); E.toggle(); break;
      case 's': case 'S': doSplit(); break;
      case 'Delete': case 'Backspace': e.preventDefault(); doDelete(); break;
      case 'ArrowLeft': e.preventDefault(); E.seek(E.getTime() - (e.shiftKey ? 1 : 1 / 30)); break;
      case 'ArrowRight': e.preventDefault(); E.seek(E.getTime() + (e.shiftKey ? 1 : 1 / 30)); break;
      case 'Home': E.seek(0); break;
      case 'End': E.seek(S.duration()); break;
      default: break;
    }
  });
  // let Space / arrows reach the editor after using a slider or button with the mouse
  document.addEventListener('pointerup', function () {
    var a = document.activeElement;
    if (a && a.type === 'range') a.blur();
  });
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('button');
    if (b && e.detail > 0) b.blur();
  });

  /* ---------- preview interaction: select / move / pick colour ---------- */
  MW.ui.pickColor = function (cb) {
    pickCb = cb;
    stage.classList.add('picking');
  };

  $('overlay').addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    var p = E.canvasPoint(e.clientX, e.clientY);

    if (pickCb) {
      var cb = pickCb, hex = null;
      pickCb = null;
      stage.classList.remove('picking');
      try { hex = E.samplePixel(p[0], p[1]); } catch (err) { /* unreadable canvas */ }
      if (hex) cb(hex);
      return;
    }

    var id = E.hitTest(p[0], p[1]);
    if (!id) { S.select(null); return; }
    S.select(id);
    var f = S.find(id);
    if (!f || f.clip.type === 'audio') return;
    e.preventDefault();

    var c = f.clip, tau = U.clamp(E.getTime() - c.start, 0, c.dur);
    var x0 = OPS.evalProp(c, 'x', tau), y0 = OPS.evalProp(c, 'y', tau);
    var dims = E.dims(), key = 'drag:' + Date.now(), moved = false;

    function move(ev) {
      var q = E.canvasPoint(ev.clientX, ev.clientY);
      var dx = q[0] - p[0], dy = q[1] - p[1];
      if (!moved && Math.abs(dx) + Math.abs(dy) < 3) return;
      moved = true;
      S.setProps(id, { x: U.round(x0 + dx / dims[0] * 100, 2), y: U.round(y0 + dy / dims[1] * 100, 2) }, tau, key);
    }
    function up() {
      global.removeEventListener('pointermove', move);
      global.removeEventListener('pointerup', up);
      global.removeEventListener('pointercancel', up);
    }
    global.addEventListener('pointermove', move);
    global.addEventListener('pointerup', up);
    global.addEventListener('pointercancel', up);
  });

  /* ---------- mobile tabs ---------- */
  $('tabBin').addEventListener('click', function () { app.dataset.tab = 'bin'; });
  $('tabInsp').addEventListener('click', function () { app.dataset.tab = 'inspector'; });

  /* ---------- export ---------- */
  var overlayEl = $('exportOverlay'), bar = $('exportBar'), barText = $('exportText');
  $('btnExport').addEventListener('click', function () {
    if (!S.hasClips()) { U.toast('Add something to the timeline first.'); return; }
    overlayEl.classList.add('show');
    bar.style.width = '0%';
    barText.textContent = 'Rendering in real time… 0%';
    MW.exporter.start({
      onProgress: function (f) {
        var pct = Math.round(f * 100);
        bar.style.width = pct + '%';
        barText.textContent = 'Rendering in real time… ' + pct + '%';
      },
      onDone: function () { overlayEl.classList.remove('show'); }
    });
  });
  $('btnExportCancel').addEventListener('click', function () { MW.exporter.cancel(); });

  /* ---------- misc ---------- */
  global.addEventListener('beforeunload', function (e) {
    if (S.hasClips()) { e.preventDefault(); e.returnValue = ''; }
  });

  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !global.Capacitor) {
    navigator.serviceWorker.register('sw.js').catch(function () { /* offline cache is optional */ });
  }
})(window);
