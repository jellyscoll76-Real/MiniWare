/* MiniWare — clipops.js
 * Pure clip data model + operations (no DOM). Unit-tested in tests/run.mjs.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var U = MW.util, A = MW.anim, SP = MW.speed;

  var MIN_DUR = 0.1;
  var EPS = 1e-4;
  var PROPS = ['x', 'y', 'scale', 'rotation', 'opacity'];

  function makeClip(type, o) {
    o = o || {};
    var c = {
      id: o.id || U.uid('clip'),
      type: type,                 // 'video' | 'image' | 'audio' | 'text'
      assetId: o.assetId || null,
      name: o.name || type,
      start: o.start || 0,        // timeline position (s)
      dur: o.dur || 5,            // timeline length (s)
      srcIn: o.srcIn || 0,        // source in-point (s)
      speed: 1,
      curve: 'none',
      cu0: 0, cu1: 1,             // slice of the speed curve used (see speed.js)
      base: { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100 },
      kf: { x: [], y: [], scale: [], rotation: [], opacity: [] },
      blend: 'normal',
      chroma: { on: false, color: '#00ff00', tol: 35 },
      fx: {
        brightness: 100, contrast: 100, saturation: 100,
        blur: { on: false, amt: 8 },
        rgb: { on: false, amt: 30 },
        vignette: { on: false, amt: 50 }
      },
      audio: { volume: 100, fadeIn: 0, fadeOut: 0 }
    };
    if (type === 'text') {
      c.base.y = 30;
      c.text = {
        content: 'Your caption', font: 'Arial', size: 64, weight: 700,
        color: '#ffffff', outlineColor: '#000000', outlineWidth: 4,
        animIn: 'fade', animOut: 'fade', animDur: 0.4
      };
    }
    return c;
  }

  function isMedia(clip) { return clip.type === 'video' || clip.type === 'audio'; }
  function evalProp(clip, prop, tau) { return A.valueAt(clip.kf[prop], tau, clip.base[prop]); }
  function hasKf(clip) { return PROPS.some(function (p) { return clip.kf[p].length > 0; }); }
  function end(clip) { return clip.start + clip.dur; }

  function allKfTimes(clip) {
    var ts = [];
    PROPS.forEach(function (p) {
      clip.kf[p].forEach(function (k) {
        if (!ts.some(function (t) { return Math.abs(t - k.t) < 0.005; })) ts.push(k.t);
      });
    });
    return ts.sort(function (a, b) { return a - b; });
  }

  function fadeFactor(clip, tau) {
    var f = 1, a = clip.audio;
    if (a.fadeIn > 0) f = Math.min(f, tau / a.fadeIn);
    if (a.fadeOut > 0) f = Math.min(f, (clip.dur - tau) / a.fadeOut);
    return U.clamp(f, 0, 1);
  }

  /* ----- keyframe trimming helpers ----- */

  function cutTailKf(clip, tau) {
    PROPS.forEach(function (p) {
      var kfs = clip.kf[p];
      if (!kfs.length) return;
      var v = A.valueAt(kfs, tau, clip.base[p]);
      var keep = kfs.filter(function (k) { return k.t < tau - EPS; });
      keep.push({ t: tau, v: v, ease: 'linear' });
      clip.kf[p] = keep;
    });
  }

  function cutHeadKf(clip, delta) {
    PROPS.forEach(function (p) {
      var kfs = clip.kf[p];
      if (!kfs.length) return;
      if (delta > 0) {
        var v = A.valueAt(kfs, delta, clip.base[p]);
        var prev = null;
        kfs.forEach(function (k) { if (k.t <= delta + EPS) prev = k; });
        var out = [{ t: 0, v: v, ease: prev ? prev.ease : 'linear' }];
        kfs.forEach(function (k) {
          if (k.t > delta + EPS) out.push({ t: U.round(k.t - delta, 4), v: k.v, ease: k.ease });
        });
        clip.kf[p] = out;
      } else {
        clip.kf[p] = kfs.map(function (k) { return { t: k.t - delta, v: k.v, ease: k.ease }; });
      }
    });
  }

  /* ----- split ----- */

  function split(clip, tau, newId) {
    if (tau < MIN_DUR || tau > clip.dur - MIN_DUR) return null;
    var left = U.clone(clip), right = U.clone(clip);
    right.id = newId || U.uid('clip');
    var r = SP.rate(clip);
    var off = isMedia(clip) ? SP.srcOffset(clip, tau) : 0;

    left.dur = tau;
    left.cu1 = clip.cu0 + r * tau;

    right.start = clip.start + tau;
    right.dur = clip.dur - tau;
    right.cu0 = left.cu1;
    right.srcIn = clip.srcIn + off;

    cutTailKf(left, tau);
    cutHeadKf(right, tau);

    left.audio.fadeOut = 0;
    right.audio.fadeIn = 0;
    if (left.text) { left.text.animOut = 'none'; right.text.animIn = 'none'; }
    return [left, right];
  }

  /* ----- trims (return a new clip, or null for no change) ----- */

  /** bounds: { minStart, assetDur }  (assetDur may be Infinity) */
  function trimLeft(clip, delta, bounds) {
    bounds = bounds || {};
    var minStart = bounds.minStart == null ? 0 : bounds.minStart;
    var d = delta;
    if (d > 0) {
      d = Math.min(d, clip.dur - MIN_DUR);
    } else {
      d = Math.max(d, minStart - clip.start);
      if (isMedia(clip) && d < 0 && clip.srcIn + SP.srcOffset(clip, d) < 0) {
        var lo = d, hi = 0;
        for (var i = 0; i < 28; i++) {
          var mid = (lo + hi) / 2;
          if (clip.srcIn + SP.srcOffset(clip, mid) < 0) lo = mid; else hi = mid;
        }
        d = hi;
      }
    }
    if (Math.abs(d) < 1e-6) return null;
    var n = U.clone(clip), r = SP.rate(clip);
    n.start = clip.start + d;
    n.dur = clip.dur - d;
    if (isMedia(clip)) n.srcIn = Math.max(0, clip.srcIn + SP.srcOffset(clip, d));
    n.cu0 = clip.cu0 + r * d;
    cutHeadKf(n, d);
    return n;
  }

  /** bounds: { maxEnd, assetDur } (either may be Infinity) */
  function trimRight(clip, delta, bounds) {
    bounds = bounds || {};
    var maxEnd = bounds.maxEnd == null ? Infinity : bounds.maxEnd;
    var assetDur = bounds.assetDur == null ? Infinity : bounds.assetDur;
    var r = SP.rate(clip);
    var nd = Math.max(MIN_DUR, clip.dur + delta);
    nd = Math.min(nd, maxEnd - clip.start);
    if (isMedia(clip) && isFinite(assetDur)) {
      var test = function (d) {
        var t = { speed: clip.speed, curve: clip.curve, cu0: clip.cu0, cu1: clip.cu0 + r * d, dur: d };
        return clip.srcIn + SP.srcOffset(t, d);
      };
      if (test(nd) > assetDur) {
        var lo = Math.min(clip.dur, nd), hi = nd;
        for (var i = 0; i < 28; i++) {
          var mid = (lo + hi) / 2;
          if (test(mid) > assetDur) hi = mid; else lo = mid;
        }
        nd = lo;
      }
    }
    nd = Math.max(MIN_DUR, nd);
    if (Math.abs(nd - clip.dur) < 1e-6) return null;
    var n = U.clone(clip);
    n.dur = nd;
    n.cu1 = clip.cu0 + r * nd;
    return n;
  }

  /* ----- speed / curve change (keeps the same source content) ----- */

  function retime(clip, patch, maxEnd) {
    maxEnd = maxEnd == null ? Infinity : maxEnd;
    var span = SP.srcSpan(clip);
    var n = U.clone(clip);
    Object.keys(patch).forEach(function (k) { n[k] = patch[k]; });
    n.speed = U.clamp(n.speed, SP.MIN, SP.MAX);
    if ('curve' in patch && patch.curve !== clip.curve) { n.cu0 = 0; n.cu1 = 1; }
    var d = SP.durForSpan(n, span);
    d = U.clamp(d, MIN_DUR, Math.max(MIN_DUR, maxEnd - clip.start));
    var ratio = d / clip.dur;
    n.dur = d;
    if (Math.abs(ratio - 1) > 1e-6) {
      PROPS.forEach(function (p) {
        n.kf[p] = n.kf[p].map(function (k) { return { t: U.round(k.t * ratio, 4), v: k.v, ease: k.ease }; });
      });
    }
    return n;
  }

  MW.clipops = {
    MIN_DUR: MIN_DUR, PROPS: PROPS,
    makeClip: makeClip, isMedia: isMedia, evalProp: evalProp, hasKf: hasKf, end: end,
    allKfTimes: allKfTimes, fadeFactor: fadeFactor,
    split: split, trimLeft: trimLeft, trimRight: trimRight, retime: retime
  };
})(typeof window !== 'undefined' ? window : globalThis);
