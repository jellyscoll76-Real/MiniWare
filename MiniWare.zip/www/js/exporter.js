/* MiniWare — exporter.js
 * Real-time WebM export: records the preview canvas (+ mixed audio) with MediaRecorder.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});
  var U = MW.util, S = MW.store, E = MW.engine, bus = MW.bus;

  var session = null;

  function pickMime() {
    var cands = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    for (var i = 0; i < cands.length; i++) {
      if (global.MediaRecorder && MediaRecorder.isTypeSupported(cands[i])) return cands[i];
    }
    return '';
  }

  /** ui: { onProgress(fraction), onDone() } */
  function start(ui) {
    ui = ui || {};
    if (session) return;
    var canvas = E.canvas;
    if (!global.MediaRecorder || !canvas.captureStream) {
      U.toast('Export is not supported in this browser.');
      if (ui.onDone) ui.onDone();
      return;
    }
    var dur = S.duration();
    if (dur <= 0) {
      U.toast('Add something to the timeline first.');
      if (ui.onDone) ui.onDone();
      return;
    }

    E.pause();
    E.seek(0);
    E.setExporting(true);

    var stream = canvas.captureStream(30);
    var detach = function () {};
    try {
      var ac = MW.media.getAudioCtx();
      if (ac) {
        var dest = ac.createMediaStreamDestination();
        detach = E.attachExportAudio(dest);
        dest.stream.getAudioTracks().forEach(function (t) { stream.addTrack(t); });
      }
    } catch (e) { /* export without audio */ }

    var mime = pickMime(), rec;
    try {
      rec = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: 6000000 } : undefined);
    } catch (e) {
      detach();
      E.setExporting(false);
      U.toast('Could not start the recorder in this browser.');
      if (ui.onDone) ui.onDone();
      return;
    }

    var chunks = [], cancelled = false;
    session = { cancel: function () { cancelled = true; E.pause(); stop(); } };

    function onTime(t) { if (ui.onProgress) ui.onProgress(Math.min(1, t / dur)); }
    function onEnded() { setTimeout(stop, 300); }
    function stop() { if (rec.state !== 'inactive') rec.stop(); }

    rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
    rec.onstop = function () {
      bus.off('time', onTime);
      bus.off('ended', onEnded);
      detach();
      E.setExporting(false);
      session = null;
      if (!cancelled && chunks.length) {
        var blob = new Blob(chunks, { type: rec.mimeType || 'video/webm' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'miniware-export.webm';
        document.body.appendChild(a);
        a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); if (a.parentNode) a.parentNode.removeChild(a); }, 10000);
        U.toast(global.Capacitor ? 'Export finished (saving from the Android app is not supported yet — use the web version).' : 'Export finished.');
      }
      if (ui.onDone) ui.onDone();
    };

    bus.on('time', onTime);
    bus.on('ended', onEnded);
    rec.start(250);
    E.play();
  }

  MW.exporter = {
    start: start,
    cancel: function () { if (session) session.cancel(); },
    isRunning: function () { return !!session; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
