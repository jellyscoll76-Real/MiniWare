/* MiniWare — util.js
 * Tiny helpers + event bus. Original code, MIT licensed.
 */
(function (global) {
  'use strict';
  var MW = (global.MW = global.MW || {});

  /* ---------- event bus ---------- */
  var listeners = {};
  MW.bus = {
    on: function (evt, fn) {
      (listeners[evt] = listeners[evt] || []).push(fn);
    },
    off: function (evt, fn) {
      listeners[evt] = (listeners[evt] || []).filter(function (f) { return f !== fn; });
    },
    emit: function (evt, data) {
      (listeners[evt] || []).slice().forEach(function (fn) {
        try { fn(data); } catch (e) { if (global.console) console.error('[bus:' + evt + ']', e); }
      });
    }
  };

  /* ---------- helpers ---------- */
  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  var U = (MW.util = {
    uid: function (prefix) {
      return (prefix || 'id') + '_' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);
    },
    clamp: function (v, a, b) { return Math.min(b, Math.max(a, v)); },
    lerp: function (a, b, t) { return a + (b - a) * t; },
    clone: function (o) { return JSON.parse(JSON.stringify(o)); },
    round: function (v, d) { var m = Math.pow(10, d || 0); return Math.round(v * m) / m; },

    /** MM:SS:FF timecode (30 fps). */
    fmtTime: function (sec, fps) {
      fps = fps || 30;
      sec = Math.max(0, sec || 0);
      var total = Math.floor(sec * fps + 1e-6);
      var f = total % fps;
      var s = Math.floor(total / fps);
      return pad(Math.floor(s / 60)) + ':' + pad(s % 60) + ':' + pad(f);
    },
    /** Short label for ruler ticks. */
    fmtShort: function (sec) {
      var m = Math.floor(sec / 60);
      var s = sec - m * 60;
      var str = s % 1 === 0 ? pad(s) : (s < 10 ? '0' : '') + s.toFixed(1);
      return m + ':' + str;
    },
    fmtDur: function (sec) {
      if (!isFinite(sec) || sec <= 0) return '';
      var m = Math.floor(sec / 60);
      var s = Math.round(sec - m * 60);
      if (s === 60) { m += 1; s = 0; }
      return m + ':' + pad(s);
    },

    hexToRgb: function (hex) {
      var h = String(hex || '#000000').replace('#', '');
      if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
      var n = parseInt(h, 16) || 0;
      return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    },
    rgbToHex: function (r, g, b) {
      function c(v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? '0' : '') + v.toString(16); }
      return '#' + c(r) + c(g) + c(b);
    },

    /** DOM builder: h('div', {class:'x', onclick:fn, style:{}}, child, child...) */
    h: function (tag, attrs) {
      var el = document.createElement(tag);
      if (attrs) {
        Object.keys(attrs).forEach(function (k) {
          var v = attrs[k];
          if (v == null || v === false) return;
          if (k === 'class') el.className = v;
          else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
          else if (k === 'dataset') Object.assign(el.dataset, v);
          else if (k.indexOf('on') === 0 && typeof v === 'function') el.addEventListener(k.slice(2), v);
          else if (v === true) el.setAttribute(k, '');
          else el.setAttribute(k, v);
        });
      }
      function add(c) {
        if (c == null || c === false) return;
        if (Array.isArray(c)) c.forEach(add);
        else el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
      }
      for (var i = 2; i < arguments.length; i++) add(arguments[i]);
      return el;
    },

    toast: function (msg, ms) {
      var host = document.getElementById('toasts');
      if (!host) return;
      var t = U.h('div', { class: 'toast' }, msg);
      host.appendChild(t);
      setTimeout(function () { t.classList.add('out'); }, ms || 2600);
      setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, (ms || 2600) + 400);
    }
  });

  /* UI hooks filled in by app.js (e.g. MW.ui.pickColor) */
  MW.ui = MW.ui || {};
})(typeof window !== 'undefined' ? window : globalThis);
