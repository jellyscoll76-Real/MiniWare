# MiniWare

A free, open-source video editor that runs entirely in the browser (and as an installable PWA / Android app).
No account, no uploads — your media never leaves your device.

**License:** MIT. **Runtime dependencies for the web app: none.** Everything is plain HTML/CSS/JS written for this
project, so there is nothing third-party to license inside `www/`. (The Android wrapper uses
[Capacitor](https://capacitorjs.com), which is MIT-licensed.)

## Features

| Area | What you get |
| --- | --- |
| Layout | Media bin · preview canvas · inspector · multi-track timeline, dark UI, works on phone / tablet / desktop |
| Preview | Real-time playback, play/pause, `MM:SS:FF` timecode, **9:16 · 16:9 · 1:1** aspect toggles, click/drag clips directly in the preview |
| Timeline | Video, overlay, text and audio tracks (add/remove/hide/mute), draggable playhead, zoom slider (also Ctrl/⌘ + wheel), split, delete, undo/redo, snapping, drag from bin, move/trim handles |
| Keyframes | Position X/Y, Scale, Rotation, Opacity; ◆ buttons, auto-keying; easing: linear, ease in/out/in-out, bounce, elastic, **shake**, hold; "Add shake burst" |
| Speed | 0.2×–5× slider + presets, speed-ramp curves (slow→fast, fast→slow, fast·slow·fast, slow·fast·slow); splitting a ramped clip stays continuous |
| Blend / Key | Normal, Screen, Multiply, Overlay; chroma key with colour picker (eyedropper on the preview) and tolerance slider |
| Text | Fonts (built-ins + upload your own .ttf/.otf/.woff), size, bold, fill, outline, entrance (fade, slide, pop, typewriter, blur) and exit animations |
| FX | Brightness, contrast, saturation, Gaussian blur, chromatic aberration (RGB split), vignette |
| Audio | Volume, fade in/out, waveforms (decoded locally) |
| Export | Real-time **WebM** export of the canvas + mixed audio (MediaRecorder) |

### Keyboard

`Space` play/pause · `S` split at playhead · `Delete` remove clip · `←/→` frame step (`Shift` = 1 s) ·
`Home/End` · `Ctrl/⌘+Z` undo · `Ctrl/⌘+Shift+Z` or `Ctrl+Y` redo

## Run it

```bash
npm start            # zero-dependency static server -> http://localhost:8080
# or just open www/index.html through any static file server
npm test             # unit tests for the editing logic (no install needed)
npm run check        # syntax + file-reference sanity check
```

No build step. Edit files in `www/`, refresh the browser.

## Project layout

```
www/                     the whole app (also the Capacitor webDir)
  index.html
  css/style.css
  js/
    util.js              helpers, event bus
    easing.js            easing curves + keyframe interpolation
    speed.js             speed ramp math
    clipops.js           pure clip operations: split / trim / retime
    store.js             project state, undo/redo, all edit actions
    media.js             import, thumbnails, waveform peaks, fonts
    engine.js            canvas compositor, playback, media sync
    exporter.js          WebM export
    timeline.js          timeline UI
    inspector.js         inspector UI
    app.js               wiring, shortcuts, bin, transport
  manifest.webmanifest   PWA manifest
  sw.js                  offline cache
tests/run.mjs            unit tests
scripts/                 dev server, sanity check, icon generator
capacitor.config.json    Android wrapper config
.github/workflows/build-apk.yml
```

## Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<you>/miniware.git
git push -u origin main
```

## Android APK (GitHub Actions)

`.github/workflows/build-apk.yml` runs on every push to `main`/`master`, on `v*` tags, on pull requests,
and manually from the **Actions** tab. It:

1. installs Node 22 and JDK 21 (Capacitor 8 requirements),
2. runs `npm test`,
3. generates the Android project (`npx cap add android`) and syncs `www/` into it,
4. builds `assembleDebug`,
5. uploads **`MiniWare-debug.apk`** as a workflow artifact (Actions → the run → *Artifacts*),
6. on a `v*` tag, also attaches the APK to a GitHub Release.

The debug APK is signed with the standard Android debug key, so it can be installed directly
(enable *install unknown apps* on the phone). For Play Store distribution, create a release keystore, store it
in repository secrets and add a signed `assembleRelease`/`bundleRelease` step.

### Build locally

```bash
npm install
npx cap add android          # once
npx cap sync android         # after every change in www/
cd android && ./gradlew assembleDebug
# -> android/app/build/outputs/apk/debug/app-debug.apk
```

Requires JDK 21 and the Android SDK (Android Studio installs both).

## PWA

Serve `www/` over HTTPS and the browser offers "Install app". The service worker caches the app shell
so the editor works offline.

## Known limitations

- **Export is real-time WebM** (a 30 s project takes 30 s to export) and the tab must stay in the foreground.
  There is no MP4 export — that needs an encoder library (e.g. ffmpeg.wasm, LGPL/GPL-licensed) which this
  project deliberately avoids. Inside the Android WebView, saving the exported file is not wired up yet; use the
  PWA/web version to export.
- Playback of imported media depends on the codecs your browser / Android WebView supports (H.264/MP4 and
  WebM are fine nearly everywhere).
- Speed ramping on very long clips relies on the browser's `playbackRate`; extreme ramps may stutter on
  slow devices.
- Chroma key, RGB split and vignette run on the CPU per frame (frames are processed at ≤ 960 px on the long
  edge); several keyed 4K layers at once will be slow.
- Project save/load is not implemented yet — closing the tab discards the project (the app warns first).

## License

MIT — see [LICENSE](LICENSE).
