// Dependency-free unit tests for the pure logic (easing, keyframes, speed ramps, clip ops, store/undo).
// Run with: npm test
import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const www = fileURLToPath(new URL('../www/js/', import.meta.url));
for (const f of ['util', 'easing', 'speed', 'clipops', 'store']) {
  vm.runInThisContext(fs.readFileSync(www + f + '.js', 'utf8'), { filename: f + '.js' });
}
const MW = globalThis.MW;
const { anim: A, speed: SP, clipops: OPS, store: S, util: U } = MW;

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ok  ' + name); }
  catch (e) { failed++; console.log('FAIL  ' + name + '\n      ' + (e && e.message)); }
}
const near = (a, b, eps = 1e-3, msg) => assert.ok(Math.abs(a - b) <= eps, (msg || '') + ` expected ${b}, got ${a}`);

function video(o = {}) {
  const { speed, curve, ...rest } = o;
  const c = OPS.makeClip('video', { assetId: 'a1', start: 0, dur: 10, ...rest });
  if (speed != null) c.speed = speed;   // makeClip always starts at 1x / no curve
  if (curve != null) c.curve = curve;
  return c;
}

console.log('easing & keyframes');
test('every easing starts at 0 and ends at 1 (hold ends at 1)', () => {
  for (const [id] of MW.easing.list) {
    const f = MW.easing.get(id);
    near(f(0), 0, 1e-6, id + ' @0');
    near(f(1), 1, 1e-6, id + ' @1');
  }
});
test('unknown easing falls back to linear', () => near(MW.easing.get('nope')(0.3), 0.3));
test('valueAt: base when no keys, clamps outside range', () => {
  assert.equal(A.valueAt([], 1, 42), 42);
  const k = [{ t: 1, v: 10, ease: 'linear' }, { t: 3, v: 30, ease: 'linear' }];
  assert.equal(A.valueAt(k, 0, 0), 10);
  assert.equal(A.valueAt(k, 9, 0), 30);
  near(A.valueAt(k, 2, 0), 20);
});
test('easeIn is slower than linear at the midpoint', () => {
  const k = [{ t: 0, v: 0, ease: 'easeIn' }, { t: 2, v: 100, ease: 'linear' }];
  assert.ok(A.valueAt(k, 1, 0) < 20);
});
test('hold keeps the value until the next key', () => {
  const k = [{ t: 0, v: 5, ease: 'hold' }, { t: 2, v: 50, ease: 'linear' }];
  assert.equal(A.valueAt(k, 1.9, 0), 5);
  assert.equal(A.valueAt(k, 2, 0), 50);
});
test('upsert sorts, merges near-duplicate times, removeNear works', () => {
  const k = [];
  A.upsert(k, 2, 20); A.upsert(k, 1, 10); A.upsert(k, 2.01, 25);
  assert.deepEqual(k.map(x => x.t), [1, 2]);
  assert.equal(k[1].v, 25);
  assert.equal(A.removeNear(k, 1), true);
  assert.equal(A.removeNear(k, 5), false);
  assert.equal(k.length, 1);
});

console.log('speed ramping');
test('constant speed maps time linearly', () => {
  const c = video({ speed: 2 });
  near(SP.srcOffset(c, 3), 6);
  near(SP.srcSpan(c), 20);
});
test('speed range constants are 0.2x - 5x', () => { assert.equal(SP.MIN, 0.2); assert.equal(SP.MAX, 5); });
test('every preset: srcOffset is monotonic and durForSpan inverts srcSpan', () => {
  for (const id of SP.order) {
    const c = video({ curve: id, speed: 1.5 });
    let prev = -1;
    for (let i = 0; i <= 50; i++) { const v = SP.srcOffset(c, 10 * i / 50); assert.ok(v >= prev - 1e-9, id); prev = v; }
    near(SP.durForSpan(c, SP.srcSpan(c)), 10, 1e-3, id);
  }
});
test('speed-up preset: later source progress per second is faster', () => {
  const c = video({ curve: 'speedUp' });
  const early = SP.srcOffset(c, 1) - SP.srcOffset(c, 0);
  const late = SP.srcOffset(c, 10) - SP.srcOffset(c, 9);
  assert.ok(late > early * 3);
});
test('retime: doubling speed halves duration and keeps the same source span', () => {
  const c = video();
  const n = OPS.retime(c, { speed: 2 });
  near(n.dur, 5);
  near(SP.srcSpan(n), SP.srcSpan(c));
});
test('retime clamps to 0.2x..5x and respects maxEnd', () => {
  const c = video();
  assert.equal(OPS.retime(c, { speed: 99 }).speed, 5);
  assert.equal(OPS.retime(c, { speed: 0.01 }).speed, 0.2);
  assert.ok(OPS.retime(c, { speed: 0.2 }, 12).dur <= 12 + 1e-9);
});
test('retime rescales keyframe times with the new duration', () => {
  const c = video();
  c.kf.x = [{ t: 0, v: 0, ease: 'linear' }, { t: 10, v: 50, ease: 'linear' }];
  const n = OPS.retime(c, { speed: 2 });
  near(n.kf.x[1].t, 5);
});

console.log('clip operations');
test('split keeps total duration, source continuity and keyframe values', () => {
  const c = video({ srcIn: 4, speed: 2, dur: 10 });
  c.kf.opacity = [{ t: 0, v: 0, ease: 'linear' }, { t: 10, v: 100, ease: 'linear' }];
  const [l, r] = OPS.split(c, 4, 'rid');
  near(l.dur + r.dur, 10);
  near(l.start + l.dur, r.start);
  near(r.srcIn, c.srcIn + SP.srcOffset(c, 4));
  near(OPS.evalProp(l, 'opacity', 4), 40);
  near(OPS.evalProp(r, 'opacity', 0), 40);
  near(OPS.evalProp(r, 'opacity', 6), 100);
});
test('split of a ramped clip stays continuous (no jump in source time)', () => {
  const c = video({ curve: 'pulse', speed: 1 });
  const [l, r] = OPS.split(c, 3.7, 'rid');
  near(l.srcIn + SP.srcSpan(l), r.srcIn, 1e-3);
  near(SP.srcSpan(l) + SP.srcSpan(r), SP.srcSpan(c), 1e-3);
  near(SP.rateAt(l, l.dur - 1e-6), SP.rateAt(r, 0), 1e-3);
});
test('split refuses cuts that leave < MIN_DUR on either side', () => {
  const c = video();
  assert.equal(OPS.split(c, 0.01), null);
  assert.equal(OPS.split(c, 9.99), null);
});
test('trimLeft shifts start/srcIn; cannot go below source start or previous clip', () => {
  const c = video({ start: 5, srcIn: 2, dur: 10 });
  const n = OPS.trimLeft(c, 3, { minStart: 0 });
  near(n.start, 8); near(n.dur, 7); near(n.srcIn, 5);
  const m = OPS.trimLeft(c, -100, { minStart: 4 });
  near(m.start, 4); near(m.srcIn, 1);
  const k = OPS.trimLeft(c, -100, { minStart: 0 });
  near(k.srcIn, 0, 1e-3);
  near(k.start, 3, 1e-3);
});
test('trimLeft/Right keep a minimum duration', () => {
  const c = video();
  assert.ok(OPS.trimLeft(c, 100, {}).dur >= OPS.MIN_DUR - 1e-9);
  assert.ok(OPS.trimRight(c, -100, {}).dur >= OPS.MIN_DUR - 1e-9);
});
test('trimRight stops at the end of the source media and at the next clip', () => {
  const c = video({ srcIn: 0, dur: 10 });
  const n = OPS.trimRight(c, 50, { assetDur: 14, maxEnd: Infinity });
  near(n.dur, 14, 0.01);
  const m = OPS.trimRight(c, 50, { assetDur: Infinity, maxEnd: 12 });
  near(m.dur, 12);
});
test('fadeFactor ramps in and out', () => {
  const c = video(); c.audio.fadeIn = 2; c.audio.fadeOut = 2;
  near(OPS.fadeFactor(c, 0), 0); near(OPS.fadeFactor(c, 1), 0.5); near(OPS.fadeFactor(c, 5), 1);
  near(OPS.fadeFactor(c, 9), 0.5); near(OPS.fadeFactor(c, 10), 0);
});

console.log('store, tracks & undo/redo');
function freshStore() {
  S.init();
  S.assets.clear();
  S.addAsset({ id: 'v', name: 'v.mp4', kind: 'video', duration: 8, w: 1920, h: 1080 });
  S.addAsset({ id: 'a', name: 'a.mp3', kind: 'audio', duration: 20 });
  S.addAsset({ id: 'i', name: 'i.png', kind: 'image', duration: 0, w: 100, h: 100 });
}
const trackOf = type => S.project.tracks.filter(t => t.type === type);

test('default project has text, overlay, video and audio tracks', () => {
  freshStore();
  assert.deepEqual(S.project.tracks.map(t => t.type), ['text', 'overlay', 'video', 'audio']);
});
test('assets land on the right track type', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); S.addAssetClip('a'); S.addAssetClip('i'); S.addTextClip(0); });
  assert.equal(trackOf('video')[0].clips.length, 1 + 1); // video + image share the video track
  assert.equal(trackOf('audio')[0].clips.length, 1);
  assert.equal(trackOf('text')[0].clips.length, 1);
});
test('new clips never overlap on the same track', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v', { start: 0 }); S.addAssetClip('v', { start: 0 }); S.addAssetClip('v', { start: 3 }); });
  const cl = trackOf('video')[0].clips.slice().sort((a, b) => a.start - b.start);
  for (let i = 1; i < cl.length; i++) assert.ok(cl[i].start >= cl[i - 1].start + cl[i - 1].dur - 1e-6);
});
test('resolveStart finds a gap or goes after the last clip', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v', { start: 0 }); });
  const tr = trackOf('video')[0];
  near(S.resolveStart(tr, null, 2, 3), 8);
  near(S.resolveStart(tr, null, 20, 3), 20);
});
test('undo / redo restore exact state, and redo clears after a new edit', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); });
  const before = JSON.stringify(S.project);
  S.mutate(() => { S.deleteSelected(); });
  assert.equal(S.hasClips(), false);
  S.undo();
  assert.equal(JSON.stringify(S.project), before);
  S.redo();
  assert.equal(S.hasClips(), false);
  S.undo();
  S.mutate(() => { S.addTrack('overlay'); });
  assert.equal(S.canRedo(), false);
});
test('rapid slider edits with the same key coalesce into one undo step', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); });
  const id = S.selectedId();
  const depth = () => { let n = 0; while (S.canUndo()) { S.undo(); n++; } return n; };
  for (let i = 0; i < 20; i++) S.mutateClip(id, c => { c.fx.brightness = 100 + i; }, 'br:' + id);
  assert.equal(depth(), 2); // add clip + one coalesced brightness edit
});
test('split action creates two clips and selects the right half', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); });
  const id = S.selectedId();
  assert.equal(S.canSplit(4), true);
  S.mutate(() => { S.splitAt(4); });
  assert.equal(trackOf('video')[0].clips.length, 2);
  assert.notEqual(S.selectedId(), id);
  assert.equal(S.canSplit(100), false);
});
test('split with nothing selected cuts every clip under the playhead', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); S.addTextClip(0); });
  S.select(null);
  S.mutate(() => { S.splitAt(2); });
  assert.equal(trackOf('video')[0].clips.length, 2);
  assert.equal(trackOf('text')[0].clips.length, 2);
});
test('keyframe toggle, auto-keying and clear', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); });
  const id = S.selectedId();
  S.setProps(id, { scale: 150 }, 1);
  assert.equal(S.find(id).clip.base.scale, 150);
  S.toggleKeyframe(id, 'scale', 1);
  assert.equal(S.find(id).clip.kf.scale.length, 1);
  S.setProps(id, { scale: 200 }, 4);                   // auto-key because the prop has keys
  near(OPS.evalProp(S.find(id).clip, 'scale', 4), 200);
  near(OPS.evalProp(S.find(id).clip, 'scale', 1), 150);
  S.clearKeyframes(id, 4);
  assert.equal(OPS.hasKf(S.find(id).clip), false);
  near(S.find(id).clip.base.scale, 200);
});
test('shake burst ends exactly on the original value', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); });
  const id = S.selectedId();
  S.addShake(id, 1, 0.6, 1);
  const c = S.find(id).clip;
  near(OPS.evalProp(c, 'x', 2), 0, 1e-6);
  near(OPS.evalProp(c, 'rotation', 5), 0, 1e-6);
  assert.ok(c.kf.x.length >= 8);
});
test('removing a track drops its clips and clears selection', () => {
  freshStore();
  S.mutate(() => { S.addAssetClip('v'); });
  const t = trackOf('video')[0];
  S.mutate(() => { S.removeTrack(t.id); });
  assert.equal(S.selected(), null);
  assert.equal(trackOf('video').length, 0);
});
test('addTrack keeps text > overlay > video > audio ordering', () => {
  freshStore();
  S.mutate(() => { S.addTrack('overlay'); S.addTrack('audio'); S.addTrack('text'); S.addTrack('video'); });
  const rank = { text: 0, overlay: 1, video: 2, audio: 3 };
  const r = S.project.tracks.map(t => rank[t.type]);
  assert.deepEqual(r, r.slice().sort((a, b) => a - b));
});
test('moveClip across tracks keeps clips sorted', () => {
  freshStore();
  S.mutate(() => { S.addTrack('video'); S.addAssetClip('i', { start: 0 }); });
  const id = S.selectedId();
  const dst = trackOf('video')[1] === S.find(id).track ? trackOf('video')[0] : trackOf('video')[1];
  S.mutate(() => { S.moveClip(id, dst.id, 3); });
  assert.equal(S.find(id).track.id, dst.id);
  near(S.find(id).clip.start, 3);
});
test('duration() is the end of the last clip', () => {
  freshStore();
  assert.equal(S.duration(), 0);
  S.mutate(() => { S.addAssetClip('v', { start: 2 }); });
  near(S.duration(), 10);
});

console.log('util');
test('timecode formatting', () => {
  assert.equal(U.fmtTime(0), '00:00:00');
  assert.equal(U.fmtTime(61.5), '01:01:15');
  assert.equal(U.fmtTime(31 / 30), '00:01:01');
  assert.equal(U.fmtTime(1.0333), '00:01:00'); // 30.999 frames -> still frame 30 of the second
  assert.equal(U.fmtTime(-3), '00:00:00');
});
test('hex <-> rgb roundtrip', () => {
  assert.deepEqual(U.hexToRgb('#00ff80'), [0, 255, 128]);
  assert.equal(U.rgbToHex(0, 255, 128), '#00ff80');
  assert.deepEqual(U.hexToRgb('#fff'), [255, 255, 255]);
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
